const { contextBridge, ipcRenderer, webUtils } = require('electron');

const SEND = new Set([
  'kennel:drop', 'kennel:context', 'kennel:dragstart', 'kennel:dragend',
  'dog:hover', 'dog:down', 'dog:up', 'dog:context',
  'fetch:go', 'search:close', 'dev:feed', 'dev:cmd',
]);
const INVOKE = new Set(['fetch:search', 'bowl:list']);
const ON = new Set(['dog:state', 'bowl:count', 'bowl:kibble', 'search:reset']);

contextBridge.exposeInMainWorld('pudding', {
  send: (channel, ...args) => {
    if (SEND.has(channel)) ipcRenderer.send(channel, ...args);
  },
  invoke: (channel, ...args) =>
    INVOKE.has(channel) ? ipcRenderer.invoke(channel, ...args) : Promise.resolve(null),
  on: (channel, cb) => {
    if (ON.has(channel)) ipcRenderer.on(channel, (_e, ...args) => cb(...args));
  },
  pathForFile: (file) => {
    try {
      return webUtils.getPathForFile(file);
    } catch {
      return null;
    }
  },
});
