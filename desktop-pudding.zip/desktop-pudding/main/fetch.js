// Find & fetch: Spotlight search plus "bring the file to the Desktop"
// or "reveal it in Finder".
const os = require('os');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { uniquePath, moveAnywhere } = require('./bowl');

const EXCLUDE = /\/(Library|node_modules|\.git|\.Trash)\//;

function search(query, { onlyin = os.homedir(), limit = 20 } = {}) {
  return new Promise((resolve) => {
    if (!query || !query.trim()) return resolve([]);
    execFile(
      'mdfind',
      ['-onlyin', onlyin, '-name', query.trim()],
      { maxBuffer: 4 * 1024 * 1024, timeout: 8000 },
      (err, stdout) => {
        if (err) return resolve([]);
        const q = query.trim().toLowerCase();
        const results = stdout
          .split('\n')
          .filter((p) => p && !EXCLUDE.test(p) && fs.existsSync(p))
          .map((p) => {
            let isDir = false;
            try {
              isDir = fs.statSync(p).isDirectory();
            } catch {}
            return { path: p, name: path.basename(p), dir: path.dirname(p), isDir };
          });
        // best matches first: exact name, then starts-with, then contains
        results.sort((a, b) => rank(a.name, q) - rank(b.name, q) || a.name.length - b.name.length);
        resolve(results.slice(0, limit));
      }
    );
  });
}

function rank(name, q) {
  const n = name.toLowerCase();
  if (n === q) return 0;
  if (n.startsWith(q)) return 1;
  if (n.includes(q)) return 2;
  return 3;
}

// Move the file to the Desktop; never overwrites — renames on collision.
function fetchToDesktop(srcPath) {
  const desktop = path.join(os.homedir(), 'Desktop');
  const name = path.basename(srcPath);
  if (path.dirname(srcPath) === desktop) return srcPath; // already there
  const dest = fs.existsSync(path.join(desktop, name))
    ? uniquePath(desktop, name, ' (fetched by Pudding)')
    : path.join(desktop, name);
  moveAnywhere(srcPath, dest);
  return dest;
}

function revealInFinder(p) {
  execFile('open', ['-R', p]);
}

// Open the file's containing folder in a Finder window with the file selected.
// Unlike `open -R`, this always shows a real window — for a Desktop file,
// `open -R` only selects the icon on the desktop surface (no window), which is
// exactly the placement we can't reliably point at. Falls back to `open -R`
// if Automation is unavailable.
function revealInFolderWindow(p) {
  const esc = p.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  const script =
    'tell application "Finder"\n' +
    'activate\n' +
    `set f to (POSIX file "${esc}") as alias\n` +
    'set w to make new Finder window\n' +
    'set target of w to (container of f)\n' +
    'select f\n' +
    'end tell';
  execFile('osascript', ['-e', script], { timeout: 4000 }, (err) => {
    if (err) execFile('open', ['-R', p]); // Automation declined → best effort
  });
}

// Screen position (top-left, in points) of a Desktop icon, via Finder.
// Resolves null if the item has no desktop icon or Automation is declined.
function desktopIconPosition(name) {
  return new Promise((resolve) => {
    const esc = name.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    execFile(
      'osascript',
      ['-e', `tell application "Finder" to get desktop position of item "${esc}"`],
      { timeout: 3000 },
      (err, stdout) => {
        if (err) return resolve(null);
        const m = String(stdout).trim().match(/(-?\d+)\D+(-?\d+)/);
        resolve(m ? { x: +m[1], y: +m[2] } : null);
      }
    );
  });
}

// Desktop icon size in points (via Finder), cached. Used to convert Finder's
// icon position (top-left) into the icon's center. Defaults to 64.
let cachedIconSize = null;
function desktopIconSize() {
  return new Promise((resolve) => {
    if (cachedIconSize) return resolve(cachedIconSize);
    execFile(
      'osascript',
      ['-e', 'tell application "Finder" to get icon size of icon view options of window of desktop'],
      { timeout: 2500 },
      (err, stdout) => {
        const n = parseInt(String(stdout).trim(), 10);
        cachedIconSize = Number.isFinite(n) && n > 0 ? n : 64;
        resolve(cachedIconSize);
      }
    );
  });
}

// If p lives on the Desktop (directly or in a subfolder), the name of the
// top-level item whose icon is visible on the desktop; else null.
function desktopTopLevelItem(p) {
  const desk = path.join(os.homedir(), 'Desktop');
  if (p === desk || !p.startsWith(desk + path.sep)) return null;
  return p.slice(desk.length + 1).split(path.sep)[0];
}

module.exports = {
  search, fetchToDesktop, revealInFinder, revealInFolderWindow,
  desktopIconPosition, desktopTopLevelItem, desktopIconSize,
};
