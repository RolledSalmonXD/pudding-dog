const {
  app, BrowserWindow, ipcMain, Menu, Tray, dialog, screen, shell, nativeImage,
} = require('electron');
const path = require('path');
const { createSettings } = require('./settings');
const { createBowl } = require('./bowl');
const fetcher = require('./fetch');
const { Dog, DOG_W, DOG_H } = require('./dog');
const { Mouse } = require('./mouse');

// Kennel size knob. The kennel sprite is a 56x46 grid; KENNEL_SCALE px per
// cell. (The dog renders at scale 4 / 48x36 → 192x144.)
const KENNEL_SCALE = 3;
const KENNEL_W = 56 * KENNEL_SCALE;
const KENNEL_H = 46 * KENNEL_SCALE;

if (!app.requestSingleInstanceLock()) app.quit();

// A desktop pet should never die on a stray frame — log and keep living.
process.on('uncaughtException', (err) => {
  console.error('Desktop Pudding recovered from:', err);
});

// The sprites are tiny 2D canvases — no need for a dedicated GPU process.
app.disableHardwareAcceleration();

let settings;
let bowl;
let mouse;
let dog;
let displayAreas = []; // cached work areas of all displays (see refreshDisplays)
let kennelWin;
let dogWin;
let searchWin;
let tray;

function floatingWindow(opts) {
  const win = new BrowserWindow({
    frame: false,
    transparent: true,
    hasShadow: false,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    acceptFirstMouse: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    ...opts,
  });
  win.setAlwaysOnTop(true, 'floating');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreenSpaces: false });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  return win;
}

function defaultKennelPos() {
  const wa = screen.getPrimaryDisplay().workArea;
  return { x: wa.x + wa.width - KENNEL_W - 24, y: wa.y + wa.height - KENNEL_H };
}

function clampKennelPos(pos) {
  const wa = screen.getPrimaryDisplay().workArea;
  return {
    x: Math.max(wa.x - KENNEL_W / 2, Math.min(pos.x, wa.x + wa.width - KENNEL_W / 2)),
    y: Math.max(wa.y, Math.min(pos.y, wa.y + wa.height - 40)),
  };
}

function createWindows() {
  const pos = clampKennelPos(settings.get('kennelPos') || defaultKennelPos());
  kennelWin = floatingWindow({ width: KENNEL_W, height: KENNEL_H, x: pos.x, y: pos.y });
  kennelWin.loadFile(path.join(__dirname, '..', 'renderer', 'kennel.html'), {
    query: { scale: String(KENNEL_SCALE) },
  });
  kennelWin.once('ready-to-show', () => kennelWin.showInactive());

  dogWin = floatingWindow({ width: DOG_W, height: DOG_H });
  dogWin.setIgnoreMouseEvents(true, { forward: true });
  dogWin.loadFile(path.join(__dirname, '..', 'renderer', 'dog.html'));

  // searchWin is created on demand (see openSearch) and destroyed when done,
  // so its renderer process doesn't sit idle.

  dog = new Dog(dogWin, {
    getKennelBounds: () => kennelWin.getBounds(),
    settings,
    mouse,
    getDisplays: () => displayAreas,
  });
  dogWin.webContents.once('did-finish-load', () => dog.start());
}

function sendCount() {
  const n = bowl.count();
  kennelWin.webContents.send('bowl:count', n);
  refreshTray();
}

/* ---------------- feed / take back ---------------- */
async function confirmAndFeed() {
  const entries = bowl.list();
  if (!entries.length) return;
  const preview = entries.slice(0, 8).map((e) => `• ${e.name}`).join('\n');
  const more = entries.length > 8 ? `\n…and ${entries.length - 8} more` : '';
  const { response } = await dialog.showMessageBox({
    type: 'warning',
    buttons: [`Feed Pudding (delete ${entries.length})`, 'Cancel'],
    defaultId: 0,
    cancelId: 1,
    message: `Feed ${entries.length} item${entries.length === 1 ? '' : 's'} to Pudding?`,
    detail: `This permanently deletes them — no take-backs once he's eaten.\n\n${preview}${more}`,
  });
  if (response !== 0) return;
  const n = bowl.feed();
  // badge clears now (files are gone), but keep kibble in the bowl until he's
  // actually finished eating it
  kennelWin.webContents.send('bowl:count', 0);
  kennelWin.webContents.send('bowl:kibble', Math.min(n, 4));
  refreshTray();
  dog.onFed(n, () => kennelWin.webContents.send('bowl:kibble', 0));
}

function takeBack() {
  const { restored, errors } = bowl.takeBackAll();
  sendCount();
  if (errors.length) {
    dialog.showErrorBox(
      'Pudding could not return everything',
      errors.map((e) => `${e.name}: ${e.error}`).join('\n')
    );
  } else if (restored.length) {
    dog.onPetted(); // happy wag as an acknowledgement
  }
}

/* ---------------- search popover ---------------- */
// Created on demand and destroyed on close, so its renderer process only
// exists while you're actually searching.
function openSearch() {
  const k = kennelWin.getBounds();
  const wa = screen.getPrimaryDisplay().workArea;
  const x = Math.max(wa.x + 8, Math.min(k.x + k.width / 2 - 170, wa.x + wa.width - 348));
  const y = Math.max(wa.y + 8, k.y - 410);

  if (!searchWin || searchWin.isDestroyed()) {
    searchWin = floatingWindow({ width: 340, height: 400, focusable: true });
    searchWin.on('closed', () => { searchWin = null; });
    searchWin.loadFile(path.join(__dirname, '..', 'renderer', 'search.html'));
  }
  const reveal = () => {
    searchWin.setPosition(Math.round(x), Math.round(y));
    searchWin.webContents.send('search:reset');
    searchWin.show();
    searchWin.focus();
  };
  if (searchWin.webContents.isLoading()) {
    searchWin.webContents.once('did-finish-load', reveal);
  } else {
    reveal();
  }
}

function closeSearch() {
  if (searchWin && !searchWin.isDestroyed()) searchWin.destroy();
  searchWin = null;
}

/* ---------------- menus ---------------- */
function buildMenu() {
  const n = bowl.count();
  return Menu.buildFromTemplate([
    {
      label: n ? `Feed Pudding — delete ${n} item${n === 1 ? '' : 's'} 🍖` : 'Feed Pudding (bowl is empty)',
      enabled: n > 0,
      click: confirmAndFeed,
    },
    { label: n ? `Take everything back (${n})` : 'Take everything back', enabled: n > 0, click: takeBack },
    { label: 'Open bowl folder', click: () => shell.openPath(bowl.itemsDir) },
    { type: 'separator' },
    { label: 'Ask Pudding to fetch… 🦴', click: openSearch },
    { type: 'separator' },
    { label: 'Sit 🐕', click: () => dog.sit() },
    { label: 'Stay 🖐️', click: () => dog.stay() },
    { label: 'Chase the mouse! 🐭', click: startChase },
    { label: 'Roam / relax', click: () => { settings.set('roam', true); dog.roam(); } },
    { type: 'separator' },
    {
      label: 'Stay in the kennel when idle',
      type: 'checkbox',
      checked: !settings.get('roam'),
      click: (item) => {
        settings.set('roam', !item.checked);
        dog.runIdle();
      },
    },
    { label: 'Send Pudding to his kennel', click: () => dog.runIdle() },
    { label: 'Pet Pudding ❤️', click: () => dog.onPetted() },
    { type: 'separator' },
    {
      label: 'Reset kennel position',
      click: () => {
        const pos = defaultKennelPos();
        kennelWin.setPosition(pos.x, pos.y);
        settings.set('kennelPos', pos);
      },
    },
    { label: 'Quit Desktop Pudding', click: () => app.quit() },
  ]);
}

function refreshTray() {
  if (tray) tray.setContextMenu(buildMenu());
}

// The dog window sweeps under the cursor during a chase, so make sure it stays
// click-through (it also warps the real cursor, which needs no permission).
function startChase() {
  dogWin.setIgnoreMouseEvents(true, { forward: true });
  dog.chase();
}

/* ---------------- ipc ---------------- */
function wireIpc() {
  ipcMain.on('kennel:drop', (_e, paths) => {
    if (!Array.isArray(paths) || !paths.length) return;
    const { staged, errors } = bowl.stage(paths.filter((p) => typeof p === 'string'));
    sendCount();
    if (staged.length) dog.onDropped();
    if (errors.length) {
      dialog.showErrorBox(
        'Some files would not go in the bowl',
        errors.map((e) => `${e.path}: ${e.error}`).join('\n')
      );
    }
  });

  ipcMain.on('kennel:context', () => {
    buildMenu().popup({ window: kennelWin });
  });
  ipcMain.on('dog:context', () => {
    buildMenu().popup({ window: dogWin });
  });

  ipcMain.handle('bowl:list', () => bowl.list());
  ipcMain.handle('fetch:search', (_e, query) => fetcher.search(String(query || '')));

  ipcMain.on('fetch:go', async (_e, { path: p, mode } = {}) => {
    if (typeof p !== 'string') return;
    closeSearch();
    const onError = (err) =>
      dialog.showErrorBox('Pudding lost the scent', `${p}\n${err.message}`);

    // Convert Finder's icon position (top-left) to the icon's center using
    // the real desktop icon size (not a hardcoded 64px).
    const half = Math.round((await fetcher.desktopIconSize()) / 2);

    // If the target lives on the Desktop, dive into its real folder icon;
    // otherwise a pixel folder pops open mid-screen (diveAt stays null).
    let diveAt = null;
    const topItem = fetcher.desktopTopLevelItem(p);
    if (topItem) {
      const iconPos = await fetcher.desktopIconPosition(topItem);
      if (iconPos) diveAt = { x: iconPos.x + half, y: iconPos.y + half };
    }

    if (mode === 'reveal') {
      dog.fetch({ mode: 'reveal', diveAt, act: () => fetcher.revealInFinder(p), onError });
    } else {
      dog.fetch({
        mode: 'fetch',
        diveAt,
        act: () => fetcher.fetchToDesktop(p),
        onError,
        // open the Desktop folder in a Finder window with the file selected —
        // a reliable "here it is" that needs no screen-coordinate guessing
        onDelivered: (dest) => fetcher.revealInFolderWindow(dest),
      });
    }
  });
  ipcMain.on('search:close', closeSearch);

  // Dev-only hook (PUD_DEV=1): run the feed choreography without the native
  // confirm dialog, so the eat animation can be driven in automated tests.
  if (process.env.PUD_DEV) {
    ipcMain.on('dev:feed', () => {
      const n = bowl.feed();
      kennelWin.webContents.send('bowl:count', 0);
      kennelWin.webContents.send('bowl:kibble', Math.min(n, 4));
      refreshTray();
      dog.onFed(n, () => kennelWin.webContents.send('bowl:kibble', 0));
    });
    ipcMain.on('dev:cmd', (_e, name) => {
      if (name === 'chase') return startChase();
      if (name === 'search') return openSearch();
      if (typeof dog[name] === 'function') dog[name]();
    });
  }

  /* kennel dragging: poll the cursor while the mouse is down */
  let kennelDrag = null;
  ipcMain.on('kennel:dragstart', (_e, { ox, oy }) => {
    kennelDrag = setInterval(() => {
      const c = screen.getCursorScreenPoint();
      kennelWin.setPosition(Math.round(c.x - ox), Math.round(c.y - oy));
    }, 16);
  });
  ipcMain.on('kennel:dragend', (_e, { moved } = {}) => {
    clearInterval(kennelDrag);
    kennelDrag = null;
    if (moved) {
      const [x, y] = kennelWin.getPosition();
      settings.set('kennelPos', { x, y });
      if (dog.state === 'sleep_kennel') dog.runIdle(); // re-seat him
    }
  });

  /* dog interactions */
  ipcMain.on('dog:hover', (_e, over) => {
    // during a drag or any choreography (esp. chase, which moves under the
    // cursor), keep the window click-through so it can't steal the pointer
    if (dog.holdTimer || dog.busy) {
      dogWin.setIgnoreMouseEvents(true, { forward: true });
      return;
    }
    dogWin.setIgnoreMouseEvents(!over, { forward: true });
  });
  let dogDown = null;
  ipcMain.on('dog:down', (_e, { ox, oy }) => {
    dogDown = { ox, oy, start: screen.getCursorScreenPoint(), held: false };
    // treat as a drag once the cursor moves a few px
    dogDown.watch = setInterval(() => {
      if (!dogDown || dogDown.held) return;
      const c = screen.getCursorScreenPoint();
      if (Math.abs(c.x - dogDown.start.x) + Math.abs(c.y - dogDown.start.y) > 6) {
        dogDown.held = true;
        dog.beginHold({ ox: dogDown.ox, oy: dogDown.oy });
      }
    }, 30);
  });
  ipcMain.on('dog:up', () => {
    if (!dogDown) return;
    clearInterval(dogDown.watch);
    const wasHeld = dogDown.held;
    dogDown = null;
    if (wasHeld) dog.endHold();
    else dog.onPetted();
  });
}

/* ---------------- app ---------------- */
// Cache every display's work area. macOS intermittently omits a display from
// getAllDisplays() (a sleeping/idle external screen), so a single snapshot or a
// per-frame read both flicker. Instead we remember each display for a few
// seconds after we last saw it: a momentary drop keeps it, a real unplug clears
// it after the retention window.
const DISPLAY_RETENTION = 6000;
const displaySeen = new Map(); // id -> { workArea, ts }
function refreshDisplays() {
  const now = Date.now();
  try {
    for (const d of screen.getAllDisplays()) {
      const a = d.workArea;
      if (a && a.width > 100 && a.height > 100 &&
        Number.isFinite(a.x) && Number.isFinite(a.y)) {
        displaySeen.set(d.id, { workArea: a, ts: now });
      }
    }
  } catch { /* keep what we have */ }
  const areas = [];
  for (const [id, v] of displaySeen) {
    if (now - v.ts <= DISPLAY_RETENTION) areas.push(v.workArea);
    else displaySeen.delete(id);
  }
  if (areas.length) displayAreas = areas;
}

app.whenReady().then(() => {
  if (app.dock) app.dock.hide();
  settings = createSettings(app.getPath('userData'));
  bowl = createBowl(path.join(app.getPath('userData'), 'bowl'));
  mouse = new Mouse(
    path.join(__dirname, 'pudmouse.swift'),
    path.join(app.getPath('userData'), 'pudmouse')
  );
  refreshDisplays();

  createWindows();
  wireIpc();

  tray = new Tray(nativeImage.createEmpty());
  tray.setTitle('🐶');
  tray.setToolTip('Desktop Pudding');
  refreshTray();

  kennelWin.webContents.once('did-finish-load', sendCount);

  for (const ev of ['display-added', 'display-removed', 'display-metrics-changed']) {
    screen.on(ev, () => {
      refreshDisplays();
      const pos = clampKennelPos(settings.get('kennelPos') || defaultKennelPos());
      kennelWin.setPosition(pos.x, pos.y);
    });
  }
  // …and poll, since a sleeping display may never fire an event when it drops
  // out of / back into getAllDisplays().
  setInterval(refreshDisplays, 1500);
});

app.on('will-quit', () => { if (mouse) mouse.stop(); });
app.on('window-all-closed', () => app.quit());
