const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { uniquePath } = require('../main/bowl');
const fetcher = require('../main/fetch');

function tmpdir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'pudding-fetch-'));
}

test('uniquePath keeps the name when free, suffixes when taken', () => {
  const dir = tmpdir();
  assert.equal(uniquePath(dir, 'a.txt'), path.join(dir, 'a.txt'));

  fs.writeFileSync(path.join(dir, 'a.txt'), 'x');
  assert.equal(
    uniquePath(dir, 'a.txt', ' (fetched by Pudding)'),
    path.join(dir, 'a (fetched by Pudding).txt')
  );

  fs.writeFileSync(path.join(dir, 'a (fetched by Pudding).txt'), 'x');
  assert.equal(
    uniquePath(dir, 'a.txt', ' (fetched by Pudding)'),
    path.join(dir, 'a (fetched by Pudding) 2.txt')
  );
});

test('uniquePath handles extensionless names', () => {
  const dir = tmpdir();
  fs.writeFileSync(path.join(dir, 'Makefile'), 'x');
  assert.equal(
    uniquePath(dir, 'Makefile', ' (fetched by Pudding)'),
    path.join(dir, 'Makefile (fetched by Pudding)')
  );
});

test('search returns [] for empty queries', async () => {
  assert.deepEqual(await fetcher.search(''), []);
  assert.deepEqual(await fetcher.search('   '), []);
});

test('search finds a real file by name (Spotlight)', async () => {
  // Uses a name we know exists on this machine; tolerant if Spotlight
  // indexing is unavailable in the environment.
  const results = await fetcher.search('IMG_8992');
  if (results.length) {
    assert.ok(results[0].name.includes('IMG_8992'));
    assert.ok(results[0].path.startsWith('/'));
  }
});
