const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createBowl } = require('../main/bowl');

function tmpdir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'pudding-test-'));
}

function makeFile(dir, name, content = 'woof') {
  const p = path.join(dir, name);
  fs.writeFileSync(p, content);
  return p;
}

test('stage moves files into the bowl and records the manifest', () => {
  const home = tmpdir();
  const bowl = createBowl(path.join(home, 'bowl'));
  const a = makeFile(home, 'a.txt');
  const b = makeFile(home, 'b.txt');

  const { staged, errors } = bowl.stage([a, b]);
  assert.equal(errors.length, 0);
  assert.equal(staged.length, 2);
  assert.equal(bowl.count(), 2);
  assert.ok(!fs.existsSync(a), 'original should be gone');
  assert.ok(fs.existsSync(staged[0].stagedPath), 'staged copy should exist');
  assert.equal(fs.readFileSync(staged[0].stagedPath, 'utf8'), 'woof');
});

test('stage handles directories and missing files', () => {
  const home = tmpdir();
  const bowl = createBowl(path.join(home, 'bowl'));
  const dir = path.join(home, 'folder');
  fs.mkdirSync(dir);
  makeFile(dir, 'inside.txt');

  const { staged, errors } = bowl.stage([dir, path.join(home, 'ghost.txt')]);
  assert.equal(staged.length, 1);
  assert.equal(errors.length, 1);
  assert.ok(fs.existsSync(path.join(staged[0].stagedPath, 'inside.txt')));
});

test('takeBackAll restores files to their original locations', () => {
  const home = tmpdir();
  const bowl = createBowl(path.join(home, 'bowl'));
  const a = makeFile(home, 'a.txt', 'original');
  bowl.stage([a]);
  assert.ok(!fs.existsSync(a));

  const { restored, errors } = bowl.takeBackAll();
  assert.equal(errors.length, 0);
  assert.deepEqual(restored, [a]);
  assert.equal(fs.readFileSync(a, 'utf8'), 'original');
  assert.equal(bowl.count(), 0);
});

test('takeBackAll renames instead of overwriting a new file at the original path', () => {
  const home = tmpdir();
  const bowl = createBowl(path.join(home, 'bowl'));
  const a = makeFile(home, 'a.txt', 'staged version');
  bowl.stage([a]);
  makeFile(home, 'a.txt', 'newer file'); // user recreated it meanwhile

  const { restored, errors } = bowl.takeBackAll();
  assert.equal(errors.length, 0);
  assert.equal(fs.readFileSync(a, 'utf8'), 'newer file', 'newer file untouched');
  assert.ok(restored[0].includes('(from Pudding)'));
  assert.equal(fs.readFileSync(restored[0], 'utf8'), 'staged version');
});

test('feed permanently deletes only bowl contents', () => {
  const home = tmpdir();
  const bowl = createBowl(path.join(home, 'bowl'));
  const keep = makeFile(home, 'keep.txt');
  const a = makeFile(home, 'a.txt');
  const b = makeFile(home, 'b.txt');
  bowl.stage([a, b]);

  const n = bowl.feed();
  assert.equal(n, 2);
  assert.equal(bowl.count(), 0);
  assert.ok(fs.existsSync(keep), 'unstaged file untouched');
  assert.equal(fs.readdirSync(bowl.itemsDir).length, 0, 'bowl emptied');
});

test('manifest persists across bowl instances', () => {
  const home = tmpdir();
  const base = path.join(home, 'bowl');
  const bowl1 = createBowl(base);
  bowl1.stage([makeFile(home, 'a.txt')]);

  const bowl2 = createBowl(base);
  assert.equal(bowl2.count(), 1);
  const { restored } = bowl2.takeBackAll();
  assert.equal(restored.length, 1);
});
