// Pixel-art sprites for Desktop Pudding, drawn procedurally on canvas.
// Everything works on a small logical grid rendered with chunky pixels,
// so animations are parametric (leg phase, tail wag, breathing) instead of
// hand-authored frame sheets.

const PAL = {
  O: '#2b2733', // outline / dark
  W: '#f7f4ec', // white fur
  S: '#dcd6c9', // white fur, shaded (far-side legs)
  K: '#26242e', // black fur
  H: '#413d4b', // black fur highlight
  P: '#ef9aab', // pink (tongue, hearts)
  T: '#3b8fa0', // collar teal
  R: '#c9564a', // kennel roof
  Rd: '#8e2a20', // roof shade
  A: '#b07443', // wood light
  B: '#8a5630', // wood plank line
  D: '#5b3b22', // wood dark / frames
  I: '#17161d', // doorway interior
  F: '#e8b765', // folder manila
  G: '#caa04f', // folder shade
  L: '#9aa0ad', // document lines
  Y: '#f2d16b', // sparkle
  Z: '#8f95c9', // zzz
  X: '#c9b9a2', // dust / sniff puffs
  E: '#ffffff', // eye glint / paper
  Q: '#75b8c8', // food bowl
  MG: '#9a9aa8', // mouse gray
  SW: '#7fbfe0', // sweat drop
};

const DOG_GRID = { w: 48, h: 36 };
const DOG_GY = 34; // ground row (feet bottom)
const KENNEL_GRID = { w: 56, h: 46 };
// Where the folder is drawn in the dog canvas during fetch (grid x)
const FOLDER_GX = 33;

function makePlotter(ctx, gw, gh, scale, flip) {
  const hits = new Uint8Array(gw * gh);
  function px(x, y, c) {
    x = Math.round(x);
    y = Math.round(y);
    if (x < 0 || y < 0 || x >= gw || y >= gh) return;
    const rx = flip ? gw - 1 - x : x;
    ctx.fillStyle = PAL[c] || c;
    ctx.fillRect(rx * scale, y * scale, scale, scale);
    hits[y * gw + rx] = 1;
  }
  function rect(x, y, w, h, c) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) px(x + i, y + j, c);
  }
  function row(x0, x1, y, c) {
    for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) px(x, y, c);
  }
  function col(x, y0, y1, c) {
    for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) px(x, y, c);
  }
  return { px, rect, row, col, hits, flip };
}

/* ---------------- dog parts ---------------- */

function leg(p, x, yTop, c, lift) {
  const y1 = DOG_GY - (lift || 0);
  for (let y = yTop; y <= y1; y++) p.row(x, x + 2, y, c);
  p.px(x + 2, y1, c === 'W' ? 'S' : c); // paw hint
}

// Curled-up-over-the-back tail, like Pudding's. wag: -1..1 side shift.
function tail(p, bY, wag) {
  const w = Math.round(wag * 2);
  const pts = [
    [9, bY - 1, 0], [8, bY - 2, 0], [7, bY - 4, 0.3], [7, bY - 6, 0.6],
    [8, bY - 8, 1], [9, bY - 9, 1], [10, bY - 8, 1], [11, bY - 7, 1],
  ];
  for (const [x, y, k] of pts) {
    p.rect(x + Math.round(w * k), y, 2, 2, 'W');
  }
}

// Head for standing-ish poses. (hx, hy) = skull top-left. Facing right.
function dogHead(p, hx, hy, o = {}) {
  // ears (black, pointy; flop = lowered/wider when eating)
  if (o.flop) {
    p.rect(hx, hy - 1, 3, 2, 'K');
    p.rect(hx + 8, hy - 1, 3, 2, 'K');
  } else {
    p.rect(hx + 1, hy - 2, 3, 3, 'K');
    p.px(hx + 1, hy - 3, 'K');
    p.rect(hx + 8, hy - 2, 3, 3, 'K');
    p.px(hx + 10, hy - 3, 'K');
    if (o.alert) { p.px(hx + 1, hy - 4, 'K'); p.px(hx + 10, hy - 4, 'K'); }
  }
  // skull (black) with rounding; the side view is mostly black — the blaze
  // runs between his eyes, so it only peeks over the front of the face
  p.rect(hx, hy + 1, 12, 9, 'K');
  p.rect(hx + 1, hy, 10, 1, 'K');
  p.rect(hx + 1, hy + 10, 10, 1, 'K');
  p.rect(hx + 10, hy + 1, 2, 4, 'W'); // blaze, edge-on above the muzzle
  // muzzle (white) + nose
  p.rect(hx + 10, hy + 5, 5, 4, 'W');
  p.px(hx + 14, hy + 4, 'W');
  p.rect(hx + 14, hy + 5, 2, 2, 'O'); // nose
  // mouth
  if (o.tongue) {
    // long lolling tongue (tired / panting)
    p.rect(hx + 11, hy + 9, 3, 2, 'O');
    const len = o.tongueLen == null ? 3 : o.tongueLen;
    p.rect(hx + 12, hy + 10, 2, len, 'P');
    p.px(hx + 13, hy + 10 + len, 'P');
  } else if (o.mouthOpen) {
    p.rect(hx + 11, hy + 9, 3, 2, 'O');
    p.px(hx + 12, hy + 10, 'P'); // tongue
  } else {
    p.row(hx + 11, hx + 13, hy + 8, 'S');
  }
  // eye (on black fur): white with pupil
  if (o.closedEye) {
    p.row(hx + 8, hx + 9, hy + 4, 'S');
  } else if (o.tired) {
    p.row(hx + 7, hx + 10, hy + 4, 'O'); // droopy half-lid
    p.px(hx + 9, hy + 5, 'O');
  } else if (o.wideEye) {
    p.rect(hx + 8, hy + 3, 3, 3, 'E');
    p.px(hx + 9, hy + 4, 'O');
  } else {
    p.rect(hx + 8, hy + 3, 2, 2, 'E');
    p.px(hx + 9, hy + 4, 'O');
  }
}

// A little caught mouse hanging from his mouth (facing right; tail curls back).
function mouseInMouth(p, x, y) {
  p.rect(x, y, 6, 4, 'MG'); // body
  p.px(x, y - 1, 'MG'); // ear (back/up)
  p.rect(x + 6, y + 1, 1, 2, 'P'); // snout/nose front
  p.px(x + 1, y + 1, 'O'); // eye
  p.px(x + 2, y + 4, 'MG'); p.px(x + 4, y + 4, 'MG'); // feet
  // thin tail curling up behind
  p.px(x - 1, y + 3, 'P'); p.px(x - 2, y + 2, 'P'); p.px(x - 2, y + 1, 'P');
}

function collar(p, x, y) {
  p.rect(x, y, 5, 2, 'T');
}

// Parametric standing pose: covers stand / walk / run / wag / carry /
// eat / sniff / held.
function standingDog(p, o = {}) {
  const bob = o.bob || 0;
  const f = Math.round((o.swing || 0) * (o.amp == null ? 2 : o.amp));
  const bY = 18 + bob; // body top row
  const lift = (v) => (Math.abs(v) >= 2 ? 1 : 0);

  // far-side legs (shaded) — diagonal pair moves opposite the near pair
  leg(p, 13 - f, bY + 7, 'S', lift(-f));
  leg(p, 24 + f, bY + 7, 'S', lift(f));
  // tail
  tail(p, bY, o.tailWag == null ? 0 : o.tailWag);
  // body (white, rounded)
  p.rect(9, bY, 22, 9, 'W');
  p.rect(10, bY - 1, 20, 1, 'W');
  p.rect(10, bY + 9, 20, 1, 'W');
  // black shoulder patch + tail-base spot
  p.rect(13, bY - 1, 9, 4, 'K');
  p.rect(14, bY + 3, 6, 2, 'K');
  p.rect(9, bY, 3, 3, 'K');
  // near-side legs (white)
  leg(p, 10 + f, bY + 7, 'W', lift(f));
  leg(p, 27 - f, bY + 7, 'W', lift(-f));
  // chest/neck
  p.rect(27, bY - 4, 5, 6, 'W');

  if (o.noHead) return { bY };

  const hx = 29;
  const hy = 5 + bob;
  dogHead(p, hx, hy, o);
  collar(p, 27, bY - 3);

  // carried document in mouth
  if (o.doc) {
    p.rect(hx + 12, hy + 7, 6, 7, 'E');
    p.row(hx + 13, hx + 16, hy + 9, 'L');
    p.row(hx + 13, hx + 16, hy + 11, 'L');
    p.px(hx + 12, hy + 7, 'S');
  }
  // caught mouse in mouth
  if (o.mouse) {
    mouseInMouth(p, hx + 13, hy + 9);
  }
  return { bY, hx, hy };
}

/* ---------------- extra props ---------------- */

function foodBowl(p, x, y, kibble) {
  p.rect(x + 1, y, 6, 1, 'Q');
  p.rect(x, y + 1, 8, 2, 'Q');
  p.row(x + 1, x + 6, y + 3, 'O');
  for (let i = 0; i < Math.min(kibble || 0, 4); i++) p.px(x + 2 + i, y, 'D');
}

function folder(p, x, y, wiggle, open) {
  const dx = Math.round(wiggle || 0);
  // back panel + tab
  p.rect(x + dx, y, 13, 10, 'F');
  p.rect(x + 1 + dx, y - 2, 5, 2, 'F');
  // dark opening
  p.row(x + 1 + dx, x + 11 + dx, y + 1, 'I');
  if (open) p.row(x + 1 + dx, x + 11 + dx, y + 2, 'I');
  // front pocket
  p.rect(x + dx, y + 3, 13, 8, 'G');
  p.row(x + dx, x + 12 + dx, y + 3, 'D');
}

function sparkles(p, cx, cy, t) {
  const pts = [
    [cx - 6, cy - 6], [cx + 8, cy - 9], [cx + 2, cy - 12], [cx + 12, cy - 4],
  ];
  pts.forEach(([x, y], i) => {
    if (Math.floor(t * 6 + i) % 2 === 0) {
      p.px(x, y, 'Y'); p.px(x - 1, y, 'Y'); p.px(x + 1, y, 'Y');
      p.px(x, y - 1, 'Y'); p.px(x, y + 1, 'Y');
    }
  });
}

function dust(p, cx, cy, t) {
  const k = Math.floor(t * 8) % 3;
  p.px(cx - 2 - k, cy - 1 - k, 'X');
  p.px(cx - 4 - k, cy - 2, 'X');
  p.px(cx - 1 - k * 2, cy - 3, 'X');
}

// The letter Z is not mirror-symmetric: when the plotter is flipped (dog
// facing left), pre-mirror the diagonal so the Z still reads correctly.
function drawZ(p, x, y, s) {
  p.row(x, x + s, y, 'Z');
  for (let i = 0; i <= s; i++) p.px(p.flip ? x + i : x + s - i, y + 1 + i, 'Z');
  p.row(x, x + s, y + s + 2, 'Z');
}

function zzz(p, t) {
  const phase = (t * 0.45) % 1;
  const y = 16 - Math.floor(phase * 8);
  drawZ(p, 36, y, 2);
  if (phase > 0.3) drawZ(p, 41, y - 5, 3);
}

function heart(p, x, y) {
  p.px(x + 1, y, 'P'); p.px(x + 3, y, 'P');
  p.row(x, x + 4, y + 1, 'P');
  p.row(x + 1, x + 3, y + 2, 'P');
  p.px(x + 2, y + 3, 'P');
}

function hearts(p, t) {
  const phase = (t * 0.8) % 1;
  const y = 12 - Math.floor(phase * 9);
  heart(p, 17, y);
  if (phase > 0.4) heart(p, 24, y + 5);
}

/* ---------------- poses ---------------- */

function poseSleepCurl(p, t, opts = {}) {
  const breathe = Math.sin(t * 3.4) > 0.4 ? 1 : 0;
  const cy = 28, rx = 12.5, ry = 6 + breathe * 0.5, cx = 21;
  // curled body blob
  for (let y = Math.ceil(cy - ry); y <= 33; y++) {
    const k = (y - cy) / ry;
    if (k * k > 1) continue;
    const half = Math.sqrt(1 - k * k) * rx;
    p.row(cx - half, cx + half, y, 'W');
  }
  // black patch on the back
  p.rect(13, 23 - breathe, 9, 3, 'K');
  // head resting on the right side (mostly black from the side)
  p.rect(26, 19 - breathe, 10, 7, 'K');
  p.rect(27, 18 - breathe, 8, 1, 'K');
  p.rect(24, 21 - breathe, 2, 3, 'W'); // blaze peeking over the face front
  p.rect(24, 24 - breathe, 5, 4, 'W'); // muzzle tucked
  p.rect(23, 25 - breathe, 1, 2, 'O'); // nose
  p.row(28, 30, 21 - breathe, 'S'); // closed eye near the front
  // floppy ears lying flat on the head
  p.rect(25, 17 - breathe, 3, 2, 'K');
  p.rect(34, 17 - breathe, 3, 2, 'K');
  // tail wrapped around the front
  p.rect(28, 30, 8, 2, 'W');
  p.px(35, 29, 'W');
  if (opts.zzz !== false) zzz(p, t);
}

function poseLie(p, t) {
  const breathe = Math.sin(t * 2.2) > 0.5 ? 1 : 0;
  // low body
  p.rect(8, 24 - breathe, 23, 6, 'W');
  p.rect(9, 23 - breathe, 21, 1, 'W');
  p.rect(9, 30, 21, 1, 'W');
  // haunch bump + patches
  p.rect(8, 22 - breathe, 7, 3, 'W');
  p.rect(12, 23 - breathe, 8, 3, 'K');
  p.rect(8, 24, 3, 3, 'K');
  // front paws stretched forward
  p.rect(28, 30, 7, 2, 'W');
  p.rect(29, 32, 7, 2, 'S');
  // tail lying beside
  p.rect(4, 27, 4, 2, 'W');
  p.px(3, 26, 'W');
  // neck + raised head
  p.rect(27, 18, 5, 8, 'W');
  dogHead(p, 28, 9 + (breathe ? 1 : 0), {});
  collar(p, 27, 19);
}

// Tuckered out: sprawled flat, head down, tongue lolling, fast panting.
function poseTired(p, t) {
  const pant = Math.sin(t * 7) > 0 ? 1 : 0; // quick breathing
  // flat sprawled body
  p.rect(8, 26, 23, 5, 'W');
  p.rect(9, 25, 21, 1, 'W');
  p.rect(9, 31, 21, 1, 'W');
  p.rect(8, 24, 7, 3, 'W'); // haunch
  p.rect(12, 25, 8, 3, 'K'); // back patch
  p.rect(8, 26, 3, 3, 'K');
  // legs splayed out flat
  p.rect(28, 31, 8, 2, 'W');
  p.rect(29, 33, 7, 1, 'S');
  p.rect(6, 30, 5, 2, 'S');
  // tail flopped down
  p.rect(4, 29, 4, 2, 'W');
  p.px(3, 30, 'W');
  // low neck + head resting near the ground
  p.rect(28, 24, 5, 5, 'W');
  dogHead(p, 30, 21 + pant, { flop: true, tired: true, tongue: true, tongueLen: 3 + pant });
  collar(p, 28, 25);
  // panting puffs + a sweat drop
  const puff = Math.floor(t * 5) % 2;
  p.px(46, 24 + puff, 'X');
  p.px(48, 22 + puff, 'X');
  if (pant) p.px(31, 18, 'SW');
}

function poseSit(p, t, o = {}) {
  // haunches
  p.rect(8, 21, 12, 12, 'W');
  p.rect(9, 20, 10, 1, 'W');
  p.rect(9, 33, 10, 1, 'W');
  p.rect(10, 20, 8, 4, 'K'); // back patch
  // folded hind leg
  p.rect(9, 29, 8, 3, 'S');
  p.px(16, 32, 'S');
  // chest diagonal up to shoulders
  p.rect(16, 17, 12, 10, 'W');
  p.rect(17, 16, 10, 1, 'W');
  // front legs, straight
  leg(p, 20, 26, 'S', 0);
  leg(p, 24, 26, 'W', 0);
  // tail curled on the ground
  p.rect(5, 30, 4, 2, 'W');
  p.px(4, 29, 'W');
  if (o.tailWag) {
    const w = Math.round(Math.sin(t * 14) * 1.5);
    p.rect(5 + w, 29, 3, 2, 'W');
  }
  // head high
  p.rect(25, 12, 5, 6, 'W');
  dogHead(p, 26, 3, o);
  collar(p, 25, 13);
  if (o.hearts) hearts(p, t);
}

function poseDig(p, t, o = {}) {
  const stroke = Math.floor(t * 7) % 2; // fast paw strokes
  // rear high on the left
  p.rect(8, 13, 11, 8, 'W');
  p.rect(9, 12, 9, 1, 'W');
  p.rect(9, 13, 4, 3, 'K');
  // tail wagging fast, high
  const w = Math.round(Math.sin(t * 18) * 2);
  p.rect(7 + w, 7, 2, 2, 'W');
  p.rect(8 + w, 9, 2, 2, 'W');
  p.px(9, 11, 'W');
  // hind legs long (rear is up)
  leg(p, 10, 20, 'S', 0);
  leg(p, 14, 20, 'W', 0);
  // body sloping down to the right
  p.rect(15, 17, 12, 8, 'W');
  p.rect(19, 16, 8, 5, 'W');
  p.rect(16, 17, 7, 3, 'K');
  // shoulders low + front legs digging
  p.rect(24, 22, 7, 6, 'W');
  leg(p, 23 + (stroke ? 2 : 0), 27, 'S', stroke ? 1 : 0);
  leg(p, 27 - (stroke ? 2 : 0), 27, 'W', stroke ? 0 : 1);
  // head down at the ground
  dogHead(p, 30, 19, { flop: true, mouthOpen: false });
  collar(p, 28, 21);
  if (o.dust !== false) dust(p, 26, 33, t);
}

// Rear half sticking out of the folder (mid-dive)
function poseRearInFolder(p, t) {
  const w = Math.round(Math.sin(t * 16) * 2);
  // angled hindquarters, head-first in the folder
  p.rect(20, 14, 10, 9, 'W');
  p.rect(21, 13, 8, 1, 'W');
  p.rect(21, 14, 4, 3, 'K');
  // tail up, wagging hard
  p.rect(19 + w, 7, 2, 2, 'W');
  p.rect(20 + w, 9, 2, 3, 'W');
  p.px(21, 12, 'W');
  // hind legs kicking
  const kick = Math.floor(t * 10) % 2;
  leg(p, 22, 22, 'S', kick ? 2 : 0);
  leg(p, 26, 22, 'W', kick ? 0 : 2);
  // shoulders disappearing toward the folder
  p.rect(28, 18, 6, 8, 'W');
}

/* ---------------- top-level draw ---------------- */

// state: sleep_kennel | sleep_floor | stand | walk | run | sit | lie | wag |
//        eat | sniff | dig | dive | emerge | carry | drop | held
// t: seconds since state start. data: {hearts, kibble, ...}
function drawDog(ctx, { state, t, dir = 1, scale = 4, data = {} }) {
  const { w, h } = DOG_GRID;
  ctx.clearRect(0, 0, w * scale, h * scale);
  const p = makePlotter(ctx, w, h, scale, dir === -1);

  switch (state) {
    case 'sleep_kennel':
    case 'sleep_floor':
      poseSleepCurl(p, t);
      break;
    case 'stand':
      standingDog(p, { tailWag: Math.sin(t * 2.5) * 0.4 });
      break;
    case 'walk': {
      const s = Math.sin(t * 2 * Math.PI * 1.6);
      standingDog(p, { swing: s, amp: 2, bob: Math.cos(t * 4 * Math.PI * 1.6) > 0 ? 0 : 1, tailWag: Math.sin(t * 6) * 0.6 });
      break;
    }
    case 'run': {
      const s = Math.sin(t * 2 * Math.PI * 3);
      standingDog(p, { swing: s, amp: 3, bob: Math.cos(t * 4 * Math.PI * 3) > 0 ? 0 : 1, tailWag: Math.sin(t * 10) * 0.8, alert: true });
      break;
    }
    case 'carry': {
      const s = Math.sin(t * 2 * Math.PI * 1.8);
      standingDog(p, { swing: s, amp: 2, bob: Math.cos(t * 4 * Math.PI * 1.8) > 0 ? 0 : 1, doc: true, tailWag: Math.sin(t * 8) * 0.8 });
      break;
    }
    case 'dragmouse': {
      const s = Math.sin(t * 2 * Math.PI * 2.2);
      standingDog(p, { swing: s, amp: 3, bob: Math.cos(t * 4 * Math.PI * 2.2) > 0 ? 0 : 1, mouse: true, alert: true, tailWag: Math.sin(t * 12) * 0.9 });
      break;
    }
    case 'sit':
      poseSit(p, t, { tailWag: data.hearts });
      break;
    case 'lie':
      poseLie(p, t);
      break;
    case 'tired':
      poseTired(p, t);
      break;
    case 'wag':
      standingDog(p, { tailWag: Math.sin(t * 16), mouthOpen: true, alert: true });
      if (data.hearts !== false) hearts(p, t);
      break;
    case 'eat': {
      // No bowl is drawn here — he lowers his muzzle to the real bowl beside
      // the kennel (main positions the window so his mouth lines up with it).
      const chomp = Math.floor(t * 4) % 2 === 0;
      const b = standingDog(p, { noHead: true, tailWag: Math.sin(t * 12) * 0.8 });
      // neck sloping down to the bowl
      p.rect(27, b.bY - 3, 5, 5, 'W');
      p.rect(29, b.bY, 4, 5, 'W');
      dogHead(p, 30, 19, { flop: true, mouthOpen: chomp });
      collar(p, 27, b.bY - 2);
      break;
    }
    case 'sniff': {
      const b = standingDog(p, { noHead: true, tailWag: Math.sin(t * 8) * 0.6 });
      p.rect(27, b.bY - 3, 5, 5, 'W');
      p.rect(29, b.bY, 4, 5, 'W');
      dogHead(p, 30, 19, { flop: true });
      collar(p, 27, b.bY - 2);
      const puff = Math.floor(t * 6) % 2;
      p.px(46, 27 + puff, 'X');
      p.px(47, 25 + puff, 'X');
      break;
    }
    case 'dig':
      if (!data.noFolder) folder(p, FOLDER_GX, 24, 0, true);
      poseDig(p, t);
      if (data.noFolder) dust(p, FOLDER_GX + 6, 34, t);
      break;
    case 'dive': {
      const ph = Math.min(t / 1.6, 1);
      const drawFolder = (wig) => { if (!data.noFolder) folder(p, FOLDER_GX, 24, wig, true); };
      if (ph < 0.35) {
        drawFolder(0);
        poseDig(p, t);
      } else if (ph < 0.72) {
        poseRearInFolder(p, t);
        drawFolder(0); // folder in front hides his front half
        sparkles(p, FOLDER_GX + 4, 24, t);
      } else {
        drawFolder(Math.sin(t * 22) * 1.2);
        sparkles(p, FOLDER_GX + 4, 24, t);
      }
      if (data.noFolder) dust(p, FOLDER_GX + 6, 34, t);
      break;
    }
    case 'emerge': {
      const ph = Math.min(t / 0.9, 1);
      if (ph < 0.4) {
        poseRearInFolder(p, t);
        if (!data.noFolder) folder(p, FOLDER_GX, 24, Math.sin(t * 22), true);
      } else {
        if (!data.noFolder) folder(p, FOLDER_GX, 24, 0, false);
        standingDog(p, { doc: true, tailWag: Math.sin(t * 14), alert: true, bob: ph < 0.6 ? 1 : 0 });
        sparkles(p, 30, 12, t);
      }
      break;
    }
    case 'drop': {
      standingDog(p, { tailWag: Math.sin(t * 14), mouthOpen: t > 0.4, alert: true });
      // the document lands on the ground in front of him
      const dy = Math.min(Math.floor(t * 24), 14);
      p.rect(42, Math.min(13 + dy, 27), 5, 6, 'E');
      p.row(43, 45, Math.min(15 + dy, 29), 'L');
      p.row(43, 45, Math.min(17 + dy, 31), 'L');
      break;
    }
    case 'held':
      standingDog(p, { swing: 0, alert: true, wideEye: true, tailWag: 0 });
      break;
    default:
      standingDog(p, {});
  }
  return p.hits;
}

/* ---------------- kennel ---------------- */

function drawKennel(ctx, { scale = 4, flash = false, kibble = 0 } = {}) {
  const { w, h } = KENNEL_GRID;
  ctx.clearRect(0, 0, w * scale, h * scale);
  const p = makePlotter(ctx, w, h, scale, false);

  // base slab
  p.rect(5, 43, 46, 2, 'D');
  // walls with plank lines
  p.rect(9, 17, 38, 26, 'A');
  for (const y of [21, 25, 29, 33, 37, 41]) p.row(10, 45, y, 'B');
  p.col(9, 17, 42, 'D');
  p.col(46, 17, 42, 'D');
  // gable roof
  for (let y = 2; y <= 15; y++) {
    const hw = 2 + (y - 2) * 1.85;
    p.row(28 - hw, 28 + hw, y, y >= 14 ? 'Rd' : 'R');
  }
  p.row(28 - 27, 28 + 27, 16, 'D'); // eave
  p.px(28, 1, 'Rd');
  // doorway (arched)
  p.rect(20, 27, 16, 16, 'I');
  p.rect(21, 25, 14, 2, 'I');
  p.rect(23, 24, 10, 1, 'I');
  // door frame
  p.col(19, 26, 42, 'D');
  p.col(36, 26, 42, 'D');
  p.row(22, 33, 23, 'D');
  p.px(20, 24, 'D'); p.px(35, 24, 'D');
  p.px(21, 24, 'D'); p.px(34, 24, 'D');
  // nameplate with a bone
  p.rect(20, 18, 16, 5, 'D');
  p.rect(21, 19, 14, 3, 'A');
  // bone: two knobs + bar
  p.row(25, 31, 20, 'E');
  p.px(24, 19, 'E'); p.px(24, 21, 'E');
  p.px(32, 19, 'E'); p.px(32, 21, 'E');
  // food bowl beside the door
  foodBowl(p, 48, 39, kibble);

  if (flash) {
    // glow around the doorway when a drag hovers over the kennel
    for (let i = 0; i < 20; i++) {
      p.px(19 - 1 + (i % 2), 26 + i * 0.8, 'Y');
      p.px(37 - (i % 2), 26 + i * 0.8, 'Y');
    }
    p.row(20, 35, 22, 'Y');
  }
  return p.hits;
}

const SPRITES = { PAL, DOG_GRID, DOG_GY, KENNEL_GRID, FOLDER_GX, drawDog, drawKennel };
if (typeof module !== 'undefined') module.exports = SPRITES;
if (typeof window !== 'undefined') window.SPRITES = SPRITES;
