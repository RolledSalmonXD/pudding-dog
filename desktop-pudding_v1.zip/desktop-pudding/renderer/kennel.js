// Kennel window renderer: drop target, staged-file badge, right-click menu,
// and manual window dragging (the main process moves the window).
const SCALE = 4;
const canvas = document.getElementById('kennel');
canvas.width = SPRITES.KENNEL_GRID.w * SCALE;
canvas.height = SPRITES.KENNEL_GRID.h * SCALE;
const ctx = canvas.getContext('2d');
const badge = document.getElementById('badge');

let count = 0; // staged files → badge
let kibble = 0; // food shown in the bowl (usually == count, but held during eating)
let flash = false;

function redraw() {
  SPRITES.drawKennel(ctx, { scale: SCALE, flash, kibble });
  badge.style.display = count > 0 ? 'block' : 'none';
  badge.textContent = String(count);
}
redraw();

window.pudding.on('bowl:count', (n) => {
  count = n;
  kibble = n;
  redraw();
});

// Set only the bowl's food, without touching the badge (used so kibble stays
// visible while Pudding eats, then empties when he's done).
window.pudding.on('bowl:kibble', (k) => {
  kibble = k;
  redraw();
});

/* ---- file drop = staging ("into the bowl") ---- */
window.addEventListener('dragover', (e) => {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  if (!flash) { flash = true; redraw(); }
});
window.addEventListener('dragleave', () => {
  if (flash) { flash = false; redraw(); }
});
window.addEventListener('drop', (e) => {
  e.preventDefault();
  flash = false;
  redraw();
  const paths = [...e.dataTransfer.files]
    .map((f) => window.pudding.pathForFile(f))
    .filter(Boolean);
  if (paths.length) window.pudding.send('kennel:drop', paths);
});

/* ---- right-click menu ---- */
window.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  window.pudding.send('kennel:context');
});

/* ---- drag the kennel around (manual: main polls the cursor) ---- */
let down = null;
window.addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;
  down = { x: e.screenX, y: e.screenY };
  window.pudding.send('kennel:dragstart', { ox: e.clientX, oy: e.clientY });
});
window.addEventListener('mouseup', (e) => {
  if (e.button !== 0 || !down) return;
  const moved = Math.abs(e.screenX - down.x) + Math.abs(e.screenY - down.y) > 4;
  down = null;
  window.pudding.send('kennel:dragend', { moved });
});
