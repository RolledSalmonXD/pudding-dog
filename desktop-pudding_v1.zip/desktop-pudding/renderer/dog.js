// Dog window renderer: animates whatever state the main process says
// Pudding is in, and reports hover (for click-through) and mouse gestures.
const SCALE = 4;
const canvas = document.getElementById('dog');
canvas.width = SPRITES.DOG_GRID.w * SCALE;
canvas.height = SPRITES.DOG_GRID.h * SCALE;
const ctx = canvas.getContext('2d');

let current = { state: 'stand', dir: 1, data: {} };
let stateStart = performance.now();
let hits = null; // occupancy grid of the last drawn frame, for hover hit-tests

window.pudding.on('dog:state', (msg) => {
  if (msg.state !== current.state) stateStart = performance.now();
  current = { data: {}, ...msg };
});

// exposed for automated tests
window.__state = () => current.state;

(function loop() {
  const t = (performance.now() - stateStart) / 1000;
  hits = SPRITES.drawDog(ctx, { ...current, t, scale: SCALE });
  requestAnimationFrame(loop);
})();

/* hover → disable click-through only when the cursor is on Pudding himself */
let hovering = false;
function overDog(e) {
  if (!hits) return false;
  const gx = Math.floor(e.clientX / SCALE);
  const gy = Math.floor(e.clientY / SCALE);
  const { w, h } = SPRITES.DOG_GRID;
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const x = gx + dx, y = gy + dy;
      if (x >= 0 && y >= 0 && x < w && y < h && hits[y * w + x]) return true;
    }
  }
  return false;
}
window.addEventListener('mousemove', (e) => {
  const over = overDog(e);
  if (over !== hovering) {
    hovering = over;
    window.pudding.send('dog:hover', over);
  }
});
window.addEventListener('mouseleave', () => {
  if (hovering) {
    hovering = false;
    window.pudding.send('dog:hover', false);
  }
});

/* clicks & drags are resolved by the main process (it owns the window position) */
window.addEventListener('mousedown', (e) => {
  if (!overDog(e)) return;
  if (e.button === 0) window.pudding.send('dog:down', { ox: e.clientX, oy: e.clientY });
});
window.addEventListener('mouseup', (e) => {
  if (e.button === 0) window.pudding.send('dog:up');
});
window.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  if (overDog(e)) window.pudding.send('dog:context');
});
