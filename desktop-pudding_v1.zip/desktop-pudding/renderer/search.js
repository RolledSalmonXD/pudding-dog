// Fetch popover: Spotlight search UI. Results come from the main process.
const q = document.getElementById('q');
const results = document.getElementById('results');

let seq = 0;
let debounce = null;

q.addEventListener('input', () => {
  clearTimeout(debounce);
  debounce = setTimeout(runSearch, 250);
});
q.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') window.pudding.send('search:close');
  if (e.key === 'Enter') runSearch();
});

async function runSearch() {
  const query = q.value.trim();
  const mySeq = ++seq;
  if (!query) { results.innerHTML = ''; return; }
  const found = await window.pudding.invoke('fetch:search', query);
  if (mySeq !== seq) return; // stale
  results.innerHTML = '';
  if (!found.length) {
    results.innerHTML = '<div class="row"><div class="dir">Pudding sniffed around but found nothing…</div></div>';
    return;
  }
  for (const f of found) {
    const row = document.createElement('div');
    row.className = 'row';
    const name = document.createElement('div');
    name.className = 'name';
    const icon = document.createElement('span');
    icon.className = 'icon';
    icon.textContent = f.isDir ? '📁' : '📄';
    name.appendChild(icon);
    name.appendChild(document.createTextNode(f.name));
    const dir = document.createElement('div');
    dir.className = 'dir';
    dir.textContent = f.dir;
    const actions = document.createElement('div');
    actions.className = 'actions';
    const fetchBtn = document.createElement('button');
    fetchBtn.textContent = 'Fetch to Desktop';
    fetchBtn.onclick = () => window.pudding.send('fetch:go', { path: f.path, mode: 'fetch' });
    const revealBtn = document.createElement('button');
    revealBtn.className = 'reveal';
    revealBtn.textContent = 'Find in Finder';
    revealBtn.onclick = () => window.pudding.send('fetch:go', { path: f.path, mode: 'reveal' });
    actions.append(fetchBtn, revealBtn);
    row.append(name, dir, actions);
    results.appendChild(row);
  }
}

window.pudding.on('search:reset', () => {
  q.value = '';
  results.innerHTML = '';
  seq++;
  setTimeout(() => q.focus(), 50);
});

window.addEventListener('blur', () => window.pudding.send('search:close'));
