const fs = require('fs');
const path = require('path');

const DEFAULTS = {
  kennelPos: null, // {x, y} — null means bottom-right default
  roam: true,
  sounds: false,
};

function createSettings(userDataDir) {
  const file = path.join(userDataDir, 'settings.json');
  let data = { ...DEFAULTS };
  try {
    data = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
  } catch {
    // first run or corrupt file — use defaults
  }

  let saveTimer = null;
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        fs.mkdirSync(userDataDir, { recursive: true });
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
      } catch (err) {
        console.error('settings save failed:', err);
      }
    }, 150);
  }

  return {
    get: (key) => data[key],
    set: (key, value) => {
      data[key] = value;
      save();
    },
    all: () => ({ ...data }),
  };
}

module.exports = { createSettings };
