// Pudding's brain: owns the dog window's position and runs choreography
// scripts (idle life, sniff, eat, fetch). The renderer only animates the
// current state; all movement is real window movement.
const { screen } = require('electron');

const DOG_W = 192; // 48 * 4
const DOG_H = 144; // 36 * 4
const FOLDER_SCREEN_X = 33 * 4; // folder x offset inside the dog window

// Window-relative anchor points (px) used to line the dog up with real
// on-screen targets. Tunable if the overlay ever looks off.
const DIG_ANCHOR = { x: 156, y: 116 }; // where he digs (→ a real folder icon)
const DROP_ANCHOR = { x: 176, y: 118 }; // where a carried doc lands
const EAT_MOUTH = { x: 16, y: 108 }; // his muzzle when eating (facing left)
const NOSE = { x: 168, y: 46 }; // his nose/mouth in the window when facing right

const rand = (a, b) => a + Math.random() * (b - a);

class Dog {
  constructor(win, { getKennelBounds, settings, mouse }) {
    this.win = win;
    this.getKennelBounds = getKennelBounds;
    this.settings = settings;
    this.mouse = mouse || null;
    this.x = 0;
    this.y = 0;
    this.dir = 1;
    this.state = 'stand';
    this.tok = null;
    this.busy = false; // a feature choreography (eat/fetch/sniff) is running
    this.chasing = false; // chasing/dragging the cursor
    this.walk = null; // {tx, ty, speed, resolve, reject}
  }

  start() {
    const rest = this.kennelRestPos();
    this.x = rest.x;
    this.y = rest.y;
    this.applyPos();
    this.win.showInactive();
    this.timer = setInterval(() => this.tick(), 33);
    this.runIdle();
  }

  stop() {
    clearInterval(this.timer);
    this.cancel();
  }

  /* ---------- geometry ---------- */
  // The display can briefly report garbage (NaN / zero-size) across sleep,
  // wake, and resolution changes. Never let that leak into positions — it
  // poisons walk targets (freezing him) and setPosition (crashing him).
  workArea() {
    const wa = screen.getPrimaryDisplay().workArea;
    if (
      wa &&
      Number.isFinite(wa.x) && Number.isFinite(wa.y) &&
      Number.isFinite(wa.width) && Number.isFinite(wa.height) &&
      wa.width > 100 && wa.height > 100
    ) {
      return wa;
    }
    return { x: 0, y: 0, width: 1280, height: 800 }; // safe fallback
  }
  applyPos() {
    if (this.win.isDestroyed()) return;
    // never hand setPosition a NaN/Infinity — recover to a safe on-screen spot
    if (!Number.isFinite(this.x) || !Number.isFinite(this.y)) {
      const wa = this.workArea(); // validated: always finite
      this.x = Number.isFinite(this.x) ? this.x : wa.x + wa.width / 2 - DOG_W / 2;
      this.y = Number.isFinite(this.y) ? this.y : wa.y + wa.height - DOG_H;
      this.walk = null; // abandon the corrupt walk
    }
    // Math.round can yield -0 (e.g. from -0.2, when the kennel is near the
    // left edge); Electron's setPosition rejects -0 with a "conversion
    // failure". Adding 0 normalizes -0 back to +0.
    const rx = Math.round(this.x) + 0;
    const ry = Math.round(this.y) + 0;
    try {
      this.win.setPosition(rx, ry);
    } catch {
      // last resort: something is still off — park at the origin, stop moving
      this.x = 0;
      this.y = 0;
      this.walk = null;
      try { this.win.setPosition(0, 0); } catch { /* window gone */ }
    }
  }
  kennelY() {
    // stand so his feet line up with the kennel's base
    const k = this.getKennelBounds();
    return k.y + k.height - DOG_H;
  }
  kennelRestPos() {
    // sleeping spot: centered in the kennel doorway
    const k = this.getKennelBounds();
    return { x: k.x + k.width / 2 - DOG_W / 2, y: this.kennelY() };
  }
  kennelFrontPos() {
    // standing spot just left of the kennel, facing it
    const k = this.getKennelBounds();
    return { x: k.x - DOG_W * 0.55, y: this.kennelY() };
  }
  bowlEatPos() {
    // stand to the right of the kennel facing left, muzzle over the real bowl
    // (drawn beside the door at kennel grid ~ (52, 40.5), scale 4)
    const k = this.getKennelBounds();
    const bowl = { x: k.x + 208, y: k.y + 162 };
    return { x: bowl.x - EAT_MOUTH.x, y: bowl.y - EAT_MOUTH.y, dir: -1 };
  }
  randomPoint() {
    const wa = this.workArea();
    return {
      x: rand(wa.x + 10, wa.x + wa.width - DOG_W - 10),
      y: rand(wa.y + 10, wa.y + wa.height - DOG_H - 10),
    };
  }

  /* ---------- state & movement primitives ---------- */
  setState(state, data) {
    this.state = state;
    if (this.win.isDestroyed()) return;
    this.win.webContents.send('dog:state', { state, dir: this.dir, data: data || {} });
  }

  tick() {
    if (!this.walk) return;
    const { tx, ty, speed } = this.walk;
    const dx = tx - this.x;
    const dy = ty - this.y;
    const dist = Math.hypot(dx, dy);
    if (Math.abs(dx) > 2) this.dir = dx < 0 ? -1 : 1;
    if (dist <= speed) {
      this.x = tx;
      this.y = ty;
      this.applyPos();
      const w = this.walk;
      this.walk = null;
      w.resolve();
      return;
    }
    this.x += (dx / dist) * speed;
    this.y += (dy / dist) * speed;
    this.applyPos();
  }

  sleep(ms, tok) {
    return new Promise((resolve, reject) => {
      const handler = () => {
        clearTimeout(id);
        reject(new Error('cancelled'));
      };
      const done = (fn) => {
        const i = tok.onCancel.indexOf(handler);
        if (i >= 0) tok.onCancel.splice(i, 1); // don't let handlers pile up
        fn();
      };
      const id = setTimeout(
        () => done(() => (tok.cancelled ? reject(new Error('cancelled')) : resolve())),
        ms
      );
      tok.onCancel.push(handler);
    });
  }

  walkTo(tx, ty, speed, tok, gait) {
    // a non-finite target would slip through the clamp below and poison every
    // future tick with NaN — refuse it outright
    if (!Number.isFinite(tx) || !Number.isFinite(ty)) return Promise.resolve();
    const wa = this.workArea();
    tx = Math.max(wa.x - DOG_W * 0.3, Math.min(tx, wa.x + wa.width - DOG_W * 0.7));
    ty = Math.max(wa.y, Math.min(ty, wa.y + wa.height - DOG_H));
    if (Math.hypot(tx - this.x, ty - this.y) < 4) return Promise.resolve();
    if (Math.abs(tx - this.x) > 2) this.dir = tx < this.x ? -1 : 1;
    this.setState(gait || 'walk');
    return new Promise((resolve, reject) => {
      this.walk = { tx, ty, speed, resolve, reject };
      tok.onCancel.push(() => {
        if (this.walk) {
          const w = this.walk;
          this.walk = null;
          w.reject(new Error('cancelled'));
        }
      });
    });
  }

  cancel() {
    if (this.tok) {
      this.tok.cancelled = true;
      this.tok.onCancel.forEach((fn) => fn());
      this.tok = null;
    }
    this.walk = null;
  }

  // Run a script exclusively; restarts idle when it finishes (unless another
  // script took over in the meantime).
  async run(script, { busy = false } = {}) {
    this.cancel();
    const tok = { cancelled: false, onCancel: [] };
    this.tok = tok;
    this.busy = busy;
    try {
      await script(tok);
    } catch {
      /* cancelled */
    }
    if (this.tok === tok) {
      this.busy = false;
      this.runIdle();
    }
  }

  /* ---------- idle life ---------- */
  runIdle() {
    this.cancel();
    const tok = { cancelled: false, onCancel: [] };
    this.tok = tok;
    this.busy = false;
    this.idleLoop(tok).catch(() => {});
  }

  async idleLoop(tok) {
    while (!tok.cancelled) {
      if (!this.settings.get('roam')) {
        await this.goToKennel(tok);
        await this.sleep(15000, tok);
        continue;
      }
      const r = Math.random();
      if (r < 0.5) {
        // nap in the kennel
        await this.goToKennel(tok);
        await this.sleep(rand(30000, 90000), tok);
      } else if (r < 0.8) {
        // wander somewhere on the screen and settle down
        const pt = this.randomPoint();
        await this.walkTo(pt.x, pt.y, 2.1, tok);
        this.setState(Math.random() < 0.5 ? 'sit' : 'lie');
        await this.sleep(rand(8000, 18000), tok);
        if (Math.random() < 0.5) {
          this.setState('sleep_floor');
          await this.sleep(rand(20000, 60000), tok);
        }
      } else {
        // mosey around a bit
        for (let i = 0; i < 2; i++) {
          const pt = this.randomPoint();
          await this.walkTo(pt.x, pt.y, 2.1, tok);
          this.setState('stand');
          await this.sleep(rand(1200, 2500), tok);
        }
        this.setState('wag', { hearts: false });
        await this.sleep(1200, tok);
      }
    }
  }

  async goToKennel(tok) {
    const front = this.kennelFrontPos();
    await this.walkTo(front.x, front.y, 2.1, tok);
    this.dir = 1;
    // slip into the doorway
    const rest = this.kennelRestPos();
    await this.walkTo(rest.x, rest.y, 1.4, tok);
    this.dir = 1;
    this.setState('sleep_kennel');
    this.win.moveTop();
  }

  /* ---------- feature choreographies ---------- */
  onDropped() {
    if (this.busy) return;
    this.run(async (tok) => {
      const front = this.kennelFrontPos();
      await this.walkTo(front.x, front.y, 4.5, tok, 'run');
      this.dir = 1;
      this.win.moveTop(); // in front of the kennel, not behind it
      this.setState('sniff');
      await this.sleep(1600, tok);
      this.setState('wag', { hearts: false });
      await this.sleep(1200, tok);
      this.setState('sit');
      await this.sleep(4000, tok);
    });
  }

  // onDone() fires when he's finished eating (used to empty the bowl's kibble).
  onFed(count, onDone) {
    this.run(
      async (tok) => {
        const eat = this.bowlEatPos();
        await this.walkTo(eat.x, eat.y, 4.5, tok, 'run');
        this.dir = eat.dir;
        this.win.moveTop(); // in front of the kennel, not behind it
        this.setState('eat');
        await this.sleep(3400, tok);
        if (onDone) onDone();
        this.setState('wag', { hearts: true });
        await this.sleep(1600, tok);
      },
      { busy: true }
    );
  }

  onPetted() {
    if (this.busy) return;
    this.run(async (tok) => {
      this.setState('wag', { hearts: true });
      await this.sleep(2000, tok);
    });
  }

  // Fetch/find choreography. Options:
  //   mode        'fetch' (carry to Desktop) | 'reveal' (show in Finder)
  //   diveAt      {x,y} screen center of a real desktop folder to dive into,
  //               or null → a pixel folder pops open mid-screen instead
  //   act         performs the fs action; for 'fetch' returns the dest path
  //   onError     (err) => {}
  //   onPlaced    async (dest) => {x,y}|null — where the delivered file landed
  //   showMarker  (point, dest) => {} — flag the spot he dropped it
  fetch({ mode, diveAt, act, onError, onPlaced, showMarker }) {
    this.run(
      async (tok) => {
        const noFolder = !!diveAt; // diving into a REAL folder → no drawn one
        let dig;
        if (diveAt) {
          dig = { x: diveAt.x - DIG_ANCHOR.x, y: diveAt.y - DIG_ANCHOR.y };
        } else {
          const wa = this.workArea();
          const fx = rand(wa.x + wa.width * 0.15, wa.x + wa.width * 0.6);
          const fy = rand(wa.y + wa.height * 0.15, wa.y + wa.height * 0.75);
          dig = { x: fx - FOLDER_SCREEN_X, y: fy - 24 * 4 };
        }
        this.dir = 1; // always dig facing right
        await this.walkTo(dig.x, dig.y, 5, tok, 'run');
        this.dir = 1;
        this.win.moveTop();
        this.setState('dig', { noFolder });
        await this.sleep(1100, tok);
        this.setState('dive', { noFolder });
        await this.sleep(1700, tok);
        this.setState('emerge', { noFolder });
        await this.sleep(1000, tok);

        if (mode === 'reveal') {
          try {
            act();
          } catch (err) {
            onError(err);
            this.setState('sit');
            await this.sleep(1500, tok);
            return;
          }
          this.setState('wag', { hearts: true });
          await this.sleep(1600, tok);
          return;
        }

        // fetch: move the file, then trot it to wherever it actually landed
        let dest;
        try {
          dest = act();
        } catch (err) {
          onError(err);
          this.setState('sit');
          await this.sleep(1500, tok);
          return;
        }
        this.setState('carry'); // holds the doc while we ask Finder where it is
        const place = onPlaced ? await onPlaced(dest) : null;
        let target;
        if (place) {
          target = { x: place.x - DROP_ANCHOR.x, y: place.y - DROP_ANCHOR.y };
        } else {
          const front = this.kennelFrontPos();
          target = { x: front.x - 40, y: front.y };
        }
        await this.walkTo(target.x, target.y, 2.6, tok, 'carry');
        this.dir = 1;
        this.win.moveTop();
        this.setState('drop');
        await this.sleep(1300, tok);
        if (place && showMarker) showMarker(place, dest);
        this.setState('wag', { hearts: true });
        await this.sleep(1600, tok);
      },
      { busy: true }
    );
  }

  /* ---------- commands ---------- */
  // move one frame toward (tx, ty); returns the distance that remained
  stepToward(tx, ty, speed) {
    const dx = tx - this.x;
    const dy = ty - this.y;
    const dist = Math.hypot(dx, dy);
    if (Math.abs(dx) > 2) this.dir = dx < 0 ? -1 : 1;
    if (dist > speed) {
      this.x += (dx / dist) * speed;
      this.y += (dy / dist) * speed;
    } else {
      this.x = tx;
      this.y = ty;
    }
    const wa = this.workArea();
    this.x = Math.max(wa.x - DOG_W * 0.3, Math.min(this.x, wa.x + wa.width - DOG_W * 0.7));
    this.y = Math.max(wa.y, Math.min(this.y, wa.y + wa.height - DOG_H));
    this.applyPos();
    return dist;
  }

  // Sit here until told otherwise (roam/another command).
  sit() {
    this.run(
      async (tok) => {
        this.setState('sit');
        while (!tok.cancelled) await this.sleep(3600000, tok);
      },
      { busy: true }
    );
  }

  // Stay put: stand → after a while lie down → after another while, sleep.
  stay() {
    this.run(
      async (tok) => {
        this.dir = 1;
        this.setState('stand');
        await this.sleep(rand(6000, 10000), tok);
        this.setState('lie');
        await this.sleep(rand(12000, 20000), tok);
        this.setState('sleep_floor');
        while (!tok.cancelled) await this.sleep(3600000, tok);
      },
      { busy: true }
    );
  }

  // Resume normal free-roaming life (cancels sit/stay/chase).
  roam() {
    this.runIdle();
  }

  // Chase the cursor. If he doesn't catch it within a minute he flops down
  // tired; if he catches it he parades it around for ~10s, then lets go.
  chase() {
    this.run(
      async (tok) => {
        this.chasing = true;
        try {
          const noseX = () => (this.dir === 1 ? NOSE.x : DOG_W - NOSE.x);
          const CATCH = 48;
          const started = Date.now();
          let caught = false;
          let lastDir = this.dir;
          this.setState('run');
          while (!tok.cancelled && Date.now() - started < 60000) {
            const c = screen.getCursorScreenPoint();
            if (Math.hypot(c.x - (this.x + noseX()), c.y - (this.y + NOSE.y)) < CATCH) {
              caught = true;
              break;
            }
            this.stepToward(c.x - noseX(), c.y - NOSE.y, 7);
            if (this.dir !== lastDir) { this.setState('run'); lastDir = this.dir; }
            await this.sleep(16, tok);
          }

          if (!caught) {
            this.setState('tired'); // tuckered out, tongue lolling
            await this.sleep(rand(9000, 14000), tok);
            return;
          }

          // caught it! parade the cursor around, then drop it
          this.setState('dragmouse');
          lastDir = this.dir;
          const dragStart = Date.now();
          let tx = this.x;
          let ty = this.y;
          let repick = 0;
          while (!tok.cancelled && Date.now() - dragStart < 10000) {
            if (Date.now() >= repick) {
              const pt = this.randomPoint();
              tx = pt.x;
              ty = pt.y;
              repick = Date.now() + rand(900, 1700);
            }
            this.stepToward(tx, ty, 4.5);
            if (this.dir !== lastDir) { this.setState('dragmouse'); lastDir = this.dir; }
            if (this.mouse) this.mouse.moveTo(this.x + noseX(), this.y + NOSE.y);
            await this.sleep(16, tok);
          }
          this.setState('wag', { hearts: false }); // drops it, pleased with himself
          await this.sleep(1600, tok);
        } finally {
          this.chasing = false;
        }
      },
      { busy: true }
    );
  }

  /* ---------- user drag ---------- */
  beginHold(offset) {
    this.cancel();
    const tok = { cancelled: false, onCancel: [] };
    this.tok = tok;
    this.busy = true;
    this.setState('held');
    this.holdOffset = offset;
    this.holdTimer = setInterval(() => {
      const c = screen.getCursorScreenPoint();
      this.x = c.x - this.holdOffset.ox;
      this.y = c.y - this.holdOffset.oy;
      this.applyPos();
    }, 16);
  }

  endHold() {
    clearInterval(this.holdTimer);
    this.holdTimer = null;
    // stay wherever he was set down (clamped on-screen)
    const wa = this.workArea();
    this.x = Math.max(wa.x - DOG_W * 0.3, Math.min(this.x, wa.x + wa.width - DOG_W * 0.7));
    this.y = Math.max(wa.y, Math.min(this.y, wa.y + wa.height - DOG_H));
    this.applyPos();
    this.busy = false;
    this.run(async (tok) => {
      this.setState('stand');
      await this.sleep(800, tok);
      this.setState('wag', { hearts: false });
      await this.sleep(1000, tok);
    });
  }
}

module.exports = { Dog, DOG_W, DOG_H };
