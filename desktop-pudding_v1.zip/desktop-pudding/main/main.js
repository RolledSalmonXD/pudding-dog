const {
  app, BrowserWindow, ipcMain, Menu, Tray, dialog, screen, shell, nativeImage,
} = require('electron');
const path = require('path');
const { createSettings } = require('./settings');
const { createBowl } = require('./bowl');
const fetcher = require('./fetch');
const { Dog, DOG_W, DOG_H } = require('./dog');
const { Mouse } = require('./mouse');

const KENNEL_W = 224; // 56 * 4
const KENNEL_H = 184; // 46 * 4

if (!app.requestSingleInstanceLock()) app.quit();

// A desktop pet should never die on a stray frame — log and keep living.
process.on('uncaughtException', (err) => {
  console.error('Desktop Pudding recovered from:', err);
});

const MARKER_W = 200;
const MARKER_H = 130;

let settings;
let bowl;
let mouse;
let dog;
let kennelWin;
let dogWin;
let searchWin;
let markerWin;
let tray;

function floatingWindow(opts) {
  const win = new BrowserWindow({
    frame: false,
    transparent: true,
    hasShadow: false,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    acceptFirstMouse: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    ...opts,
  });
  win.setAlwaysOnTop(true, 'floating');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreenSpaces: false });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  return win;
}

function defaultKennelPos() {
  const wa = screen.getPrimaryDisplay().workArea;
  return { x: wa.x + wa.width - KENNEL_W - 24, y: wa.y + wa.height - KENNEL_H };
}

function clampKennelPos(pos) {
  const wa = screen.getPrimaryDisplay().workArea;
  return {
    x: Math.max(wa.x - KENNEL_W / 2, Math.min(pos.x, wa.x + wa.width - KENNEL_W / 2)),
    y: Math.max(wa.y, Math.min(pos.y, wa.y + wa.height - 40)),
  };
}

function createWindows() {
  const pos = clampKennelPos(settings.get('kennelPos') || defaultKennelPos());
  kennelWin = floatingWindow({ width: KENNEL_W, height: KENNEL_H, x: pos.x, y: pos.y });
  kennelWin.loadFile(path.join(__dirname, '..', 'renderer', 'kennel.html'));
  kennelWin.once('ready-to-show', () => kennelWin.showInactive());

  dogWin = floatingWindow({ width: DOG_W, height: DOG_H });
  dogWin.setIgnoreMouseEvents(true, { forward: true });
  dogWin.loadFile(path.join(__dirname, '..', 'renderer', 'dog.html'));

  searchWin = floatingWindow({ width: 340, height: 400, focusable: true });
  searchWin.loadFile(path.join(__dirname, '..', 'renderer', 'search.html'));

  markerWin = floatingWindow({ width: MARKER_W, height: MARKER_H });
  markerWin.setIgnoreMouseEvents(true);
  markerWin.loadFile(path.join(__dirname, '..', 'renderer', 'marker.html'));

  dog = new Dog(dogWin, {
    getKennelBounds: () => kennelWin.getBounds(),
    settings,
    mouse,
  });
  dogWin.webContents.once('did-finish-load', () => dog.start());
}

function sendCount() {
  const n = bowl.count();
  kennelWin.webContents.send('bowl:count', n);
  refreshTray();
}

/* ---------------- feed / take back ---------------- */
async function confirmAndFeed() {
  const entries = bowl.list();
  if (!entries.length) return;
  const preview = entries.slice(0, 8).map((e) => `• ${e.name}`).join('\n');
  const more = entries.length > 8 ? `\n…and ${entries.length - 8} more` : '';
  const { response } = await dialog.showMessageBox({
    type: 'warning',
    buttons: [`Feed Pudding (delete ${entries.length})`, 'Cancel'],
    defaultId: 0,
    cancelId: 1,
    message: `Feed ${entries.length} item${entries.length === 1 ? '' : 's'} to Pudding?`,
    detail: `This permanently deletes them — no take-backs once he's eaten.\n\n${preview}${more}`,
  });
  if (response !== 0) return;
  const n = bowl.feed();
  // badge clears now (files are gone), but keep kibble in the bowl until he's
  // actually finished eating it
  kennelWin.webContents.send('bowl:count', 0);
  kennelWin.webContents.send('bowl:kibble', Math.min(n, 4));
  refreshTray();
  dog.onFed(n, () => kennelWin.webContents.send('bowl:kibble', 0));
}

function takeBack() {
  const { restored, errors } = bowl.takeBackAll();
  sendCount();
  if (errors.length) {
    dialog.showErrorBox(
      'Pudding could not return everything',
      errors.map((e) => `${e.name}: ${e.error}`).join('\n')
    );
  } else if (restored.length) {
    dog.onPetted(); // happy wag as an acknowledgement
  }
}

/* ---------------- search popover ---------------- */
function openSearch() {
  const k = kennelWin.getBounds();
  const wa = screen.getPrimaryDisplay().workArea;
  const x = Math.max(wa.x + 8, Math.min(k.x + k.width / 2 - 170, wa.x + wa.width - 348));
  const y = Math.max(wa.y + 8, k.y - 410);
  searchWin.setPosition(Math.round(x), Math.round(y));
  searchWin.webContents.send('search:reset');
  searchWin.show();
  searchWin.focus();
}

function closeSearch() {
  if (searchWin.isVisible()) searchWin.hide();
}

let markerTimer = null;
// point = screen position (icon center) where Pudding dropped the file
function showMarker(point, dest) {
  const wa = screen.getPrimaryDisplay().workArea;
  const x = Math.max(wa.x, Math.min(point.x - MARKER_W / 2, wa.x + wa.width - MARKER_W));
  const y = Math.max(wa.y, point.y - MARKER_H); // bubble above, arrow at the icon
  markerWin.setPosition(Math.round(x), Math.round(y));
  markerWin.webContents.send('marker:show', path.basename(dest));
  markerWin.showInactive();
  markerWin.moveTop();
  clearTimeout(markerTimer);
  markerTimer = setTimeout(() => markerWin.hide(), 3800);
}

/* ---------------- menus ---------------- */
function buildMenu() {
  const n = bowl.count();
  return Menu.buildFromTemplate([
    {
      label: n ? `Feed Pudding — delete ${n} item${n === 1 ? '' : 's'} 🍖` : 'Feed Pudding (bowl is empty)',
      enabled: n > 0,
      click: confirmAndFeed,
    },
    { label: n ? `Take everything back (${n})` : 'Take everything back', enabled: n > 0, click: takeBack },
    { label: 'Open bowl folder', click: () => shell.openPath(bowl.itemsDir) },
    { type: 'separator' },
    { label: 'Ask Pudding to fetch… 🦴', click: openSearch },
    { type: 'separator' },
    { label: 'Sit 🐕', click: () => dog.sit() },
    { label: 'Stay 🖐️', click: () => dog.stay() },
    { label: 'Chase the mouse! 🐭', click: startChase },
    { label: 'Roam / relax', click: () => { settings.set('roam', true); dog.roam(); } },
    { type: 'separator' },
    {
      label: 'Stay in the kennel when idle',
      type: 'checkbox',
      checked: !settings.get('roam'),
      click: (item) => {
        settings.set('roam', !item.checked);
        dog.runIdle();
      },
    },
    { label: 'Send Pudding to his kennel', click: () => dog.runIdle() },
    { label: 'Pet Pudding ❤️', click: () => dog.onPetted() },
    { type: 'separator' },
    {
      label: 'Reset kennel position',
      click: () => {
        const pos = defaultKennelPos();
        kennelWin.setPosition(pos.x, pos.y);
        settings.set('kennelPos', pos);
      },
    },
    { label: 'Quit Desktop Pudding', click: () => app.quit() },
  ]);
}

function refreshTray() {
  if (tray) tray.setContextMenu(buildMenu());
}

// The dog window sweeps under the cursor during a chase, so make sure it stays
// click-through (it also warps the real cursor, which needs no permission).
function startChase() {
  dogWin.setIgnoreMouseEvents(true, { forward: true });
  dog.chase();
}

/* ---------------- ipc ---------------- */
function wireIpc() {
  ipcMain.on('kennel:drop', (_e, paths) => {
    if (!Array.isArray(paths) || !paths.length) return;
    const { staged, errors } = bowl.stage(paths.filter((p) => typeof p === 'string'));
    sendCount();
    if (staged.length) dog.onDropped();
    if (errors.length) {
      dialog.showErrorBox(
        'Some files would not go in the bowl',
        errors.map((e) => `${e.path}: ${e.error}`).join('\n')
      );
    }
  });

  ipcMain.on('kennel:context', () => {
    buildMenu().popup({ window: kennelWin });
  });
  ipcMain.on('dog:context', () => {
    buildMenu().popup({ window: dogWin });
  });

  ipcMain.handle('bowl:list', () => bowl.list());
  ipcMain.handle('fetch:search', (_e, query) => fetcher.search(String(query || '')));

  ipcMain.on('fetch:go', async (_e, { path: p, mode } = {}) => {
    if (typeof p !== 'string') return;
    closeSearch();
    const onError = (err) =>
      dialog.showErrorBox('Pudding lost the scent', `${p}\n${err.message}`);

    // If the target lives on the Desktop, dive into its real folder icon;
    // otherwise a pixel folder pops open mid-screen (diveAt stays null).
    let diveAt = null;
    const topItem = fetcher.desktopTopLevelItem(p);
    if (topItem) {
      const iconPos = await fetcher.desktopIconPosition(topItem);
      if (iconPos) diveAt = { x: iconPos.x + 32, y: iconPos.y + 32 };
    }

    if (mode === 'reveal') {
      dog.fetch({ mode: 'reveal', diveAt, act: () => fetcher.revealInFinder(p), onError });
    } else {
      dog.fetch({
        mode: 'fetch',
        diveAt,
        act: () => fetcher.fetchToDesktop(p),
        onError,
        onPlaced: async (dest) => {
          const pos = await fetcher.waitForIconPosition(path.basename(dest));
          return pos ? { x: pos.x + 32, y: pos.y + 32 } : null;
        },
        showMarker,
      });
    }
  });
  ipcMain.on('search:close', closeSearch);

  // Dev-only hook (PUD_DEV=1): run the feed choreography without the native
  // confirm dialog, so the eat animation can be driven in automated tests.
  if (process.env.PUD_DEV) {
    ipcMain.on('dev:feed', () => {
      const n = bowl.feed();
      kennelWin.webContents.send('bowl:count', 0);
      kennelWin.webContents.send('bowl:kibble', Math.min(n, 4));
      refreshTray();
      dog.onFed(n, () => kennelWin.webContents.send('bowl:kibble', 0));
    });
    ipcMain.on('dev:cmd', (_e, name) => {
      if (name === 'chase') return startChase();
      if (typeof dog[name] === 'function') dog[name]();
    });
  }

  /* kennel dragging: poll the cursor while the mouse is down */
  let kennelDrag = null;
  ipcMain.on('kennel:dragstart', (_e, { ox, oy }) => {
    kennelDrag = setInterval(() => {
      const c = screen.getCursorScreenPoint();
      kennelWin.setPosition(Math.round(c.x - ox), Math.round(c.y - oy));
    }, 16);
  });
  ipcMain.on('kennel:dragend', (_e, { moved } = {}) => {
    clearInterval(kennelDrag);
    kennelDrag = null;
    if (moved) {
      const [x, y] = kennelWin.getPosition();
      settings.set('kennelPos', { x, y });
      if (dog.state === 'sleep_kennel') dog.runIdle(); // re-seat him
    }
  });

  /* dog interactions */
  ipcMain.on('dog:hover', (_e, over) => {
    // during a drag or any choreography (esp. chase, which moves under the
    // cursor), keep the window click-through so it can't steal the pointer
    if (dog.holdTimer || dog.busy) {
      dogWin.setIgnoreMouseEvents(true, { forward: true });
      return;
    }
    dogWin.setIgnoreMouseEvents(!over, { forward: true });
  });
  let dogDown = null;
  ipcMain.on('dog:down', (_e, { ox, oy }) => {
    dogDown = { ox, oy, start: screen.getCursorScreenPoint(), held: false };
    // treat as a drag once the cursor moves a few px
    dogDown.watch = setInterval(() => {
      if (!dogDown || dogDown.held) return;
      const c = screen.getCursorScreenPoint();
      if (Math.abs(c.x - dogDown.start.x) + Math.abs(c.y - dogDown.start.y) > 6) {
        dogDown.held = true;
        dog.beginHold({ ox: dogDown.ox, oy: dogDown.oy });
      }
    }, 30);
  });
  ipcMain.on('dog:up', () => {
    if (!dogDown) return;
    clearInterval(dogDown.watch);
    const wasHeld = dogDown.held;
    dogDown = null;
    if (wasHeld) dog.endHold();
    else dog.onPetted();
  });
}

/* ---------------- app ---------------- */
app.whenReady().then(() => {
  if (app.dock) app.dock.hide();
  settings = createSettings(app.getPath('userData'));
  bowl = createBowl(path.join(app.getPath('userData'), 'bowl'));
  mouse = new Mouse(
    path.join(__dirname, 'pudmouse.swift'),
    path.join(app.getPath('userData'), 'pudmouse')
  );

  createWindows();
  wireIpc();

  tray = new Tray(nativeImage.createEmpty());
  tray.setTitle('🐶');
  tray.setToolTip('Desktop Pudding');
  refreshTray();

  kennelWin.webContents.once('did-finish-load', sendCount);

  screen.on('display-metrics-changed', () => {
    const pos = clampKennelPos(settings.get('kennelPos') || defaultKennelPos());
    kennelWin.setPosition(pos.x, pos.y);
  });
});

app.on('will-quit', () => { if (mouse) mouse.stop(); });
app.on('window-all-closed', () => app.quit());
