// Tiny cursor mover for Desktop Pudding. Reads "x y" lines on stdin and warps
// the mouse cursor there (global display points, top-left origin — matches
// Electron's screen coordinates). CGWarpMouseCursorPosition needs no special
// permission. Exits when stdin closes, so the app fully controls its lifetime.
import CoreGraphics
import Foundation

while let line = readLine(strippingNewline: true) {
  let parts = line.split(separator: " ")
  if parts.count == 2, let x = Double(parts[0]), let y = Double(parts[1]) {
    CGWarpMouseCursorPosition(CGPoint(x: x, y: y))
  }
}
