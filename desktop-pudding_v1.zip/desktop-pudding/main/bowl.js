// The kennel's "bowl": a staging area for files dropped on the kennel.
// Files are MOVED here (recoverable) until the user feeds them to Pudding,
// which permanently deletes them.
const fs = require('fs');
const path = require('path');

function moveAnywhere(src, dest) {
  try {
    fs.renameSync(src, dest);
  } catch (err) {
    if (err.code !== 'EXDEV') throw err;
    // cross-volume move: copy then remove
    fs.cpSync(src, dest, { recursive: true, errorOnExist: true, force: false });
    fs.rmSync(src, { recursive: true, force: true });
  }
}

// "name.ext" -> "name suffix.ext", keeping directories sane too
function withSuffix(name, suffix) {
  const ext = path.extname(name);
  const base = ext ? name.slice(0, -ext.length) : name;
  return `${base}${suffix}${ext}`;
}

function uniquePath(dir, name, suffix = '') {
  let candidate = suffix ? withSuffix(name, suffix) : name;
  let n = 2;
  while (fs.existsSync(path.join(dir, candidate))) {
    candidate = withSuffix(name, `${suffix} ${n}`);
    n += 1;
  }
  return path.join(dir, candidate);
}

function createBowl(baseDir) {
  const itemsDir = path.join(baseDir, 'items');
  const manifestFile = path.join(baseDir, 'manifest.json');
  fs.mkdirSync(itemsDir, { recursive: true });

  let manifest = [];
  try {
    manifest = JSON.parse(fs.readFileSync(manifestFile, 'utf8'));
  } catch {
    manifest = [];
  }

  function saveManifest() {
    fs.writeFileSync(manifestFile, JSON.stringify(manifest, null, 2));
  }

  function stage(paths) {
    const staged = [];
    const errors = [];
    for (const src of paths) {
      try {
        if (!fs.existsSync(src)) throw new Error('file not found');
        const name = path.basename(src);
        const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const slot = path.join(itemsDir, id);
        fs.mkdirSync(slot);
        const dest = path.join(slot, name);
        moveAnywhere(src, dest);
        const entry = { id, name, originalPath: src, stagedPath: dest };
        manifest.push(entry);
        staged.push(entry);
      } catch (err) {
        errors.push({ path: src, error: err.message });
      }
    }
    saveManifest();
    return { staged, errors };
  }

  function list() {
    return manifest.map((e) => ({ ...e }));
  }

  function count() {
    return manifest.length;
  }

  // Permanently delete everything in the bowl.
  function feed() {
    const n = manifest.length;
    for (const entry of manifest) {
      fs.rmSync(path.dirname(entry.stagedPath), { recursive: true, force: true });
    }
    manifest = [];
    saveManifest();
    return n;
  }

  // Restore all staged files to where they came from (collision-safe).
  function takeBackAll() {
    const restored = [];
    const errors = [];
    const remaining = [];
    for (const entry of manifest) {
      try {
        const dir = path.dirname(entry.originalPath);
        fs.mkdirSync(dir, { recursive: true });
        const dest = fs.existsSync(entry.originalPath)
          ? uniquePath(dir, entry.name, ' (from Pudding)')
          : entry.originalPath;
        moveAnywhere(entry.stagedPath, dest);
        fs.rmSync(path.dirname(entry.stagedPath), { recursive: true, force: true });
        restored.push(dest);
      } catch (err) {
        errors.push({ name: entry.name, error: err.message });
        remaining.push(entry);
      }
    }
    manifest = remaining;
    saveManifest();
    return { restored, errors };
  }

  return { stage, list, count, feed, takeBackAll, itemsDir, uniquePath };
}

module.exports = { createBowl, uniquePath, moveAnywhere };
