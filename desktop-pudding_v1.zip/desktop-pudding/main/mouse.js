// Manages the compiled Swift cursor-mover (pudmouse). Compiles it once
// (cached in userData), then keeps a long-lived process we feed positions to.
// If swiftc is missing or compilation fails, `available` stays false and
// moveTo() is a harmless no-op (chase still animates, just doesn't grab the
// real cursor).
const { spawn } = require('child_process');
const fs = require('fs');

class Mouse {
  constructor(srcPath, binPath) {
    this.src = srcPath;
    this.bin = binPath;
    this.ready = false;
    this.proc = null;
    this.build();
  }

  build() {
    try {
      const fresh =
        fs.existsSync(this.bin) &&
        fs.statSync(this.bin).mtimeMs >= fs.statSync(this.src).mtimeMs;
      if (fresh) {
        this.ready = true;
        return;
      }
    } catch {
      /* fall through to compile */
    }
    try {
      const p = spawn('swiftc', ['-O', this.src, '-o', this.bin], { stdio: 'ignore' });
      p.on('exit', (code) => {
        this.ready = code === 0 && fs.existsSync(this.bin);
      });
      p.on('error', () => {
        this.ready = false;
      });
    } catch {
      this.ready = false;
    }
  }

  get available() {
    return this.ready;
  }

  ensureProc() {
    if (!this.ready) return false;
    if (this.proc && this.proc.exitCode === null && !this.proc.killed) return true;
    try {
      this.proc = spawn(this.bin, [], { stdio: ['pipe', 'ignore', 'ignore'] });
      this.proc.on('error', () => { this.proc = null; });
      this.proc.on('exit', () => { this.proc = null; });
      return true;
    } catch {
      this.proc = null;
      return false;
    }
  }

  moveTo(x, y) {
    if (!this.ensureProc()) return;
    try {
      this.proc.stdin.write(`${Math.round(x)} ${Math.round(y)}\n`);
    } catch {
      /* pipe closed; will respawn next call */
    }
  }

  stop() {
    if (this.proc) {
      try { this.proc.stdin.end(); } catch {}
      try { this.proc.kill(); } catch {}
      this.proc = null;
    }
  }
}

module.exports = { Mouse };
