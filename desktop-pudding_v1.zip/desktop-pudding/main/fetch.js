// Find & fetch: Spotlight search plus "bring the file to the Desktop"
// or "reveal it in Finder".
const os = require('os');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { uniquePath, moveAnywhere } = require('./bowl');

const EXCLUDE = /\/(Library|node_modules|\.git|\.Trash)\//;

function search(query, { onlyin = os.homedir(), limit = 20 } = {}) {
  return new Promise((resolve) => {
    if (!query || !query.trim()) return resolve([]);
    execFile(
      'mdfind',
      ['-onlyin', onlyin, '-name', query.trim()],
      { maxBuffer: 4 * 1024 * 1024, timeout: 8000 },
      (err, stdout) => {
        if (err) return resolve([]);
        const q = query.trim().toLowerCase();
        const results = stdout
          .split('\n')
          .filter((p) => p && !EXCLUDE.test(p) && fs.existsSync(p))
          .map((p) => {
            let isDir = false;
            try {
              isDir = fs.statSync(p).isDirectory();
            } catch {}
            return { path: p, name: path.basename(p), dir: path.dirname(p), isDir };
          });
        // best matches first: exact name, then starts-with, then contains
        results.sort((a, b) => rank(a.name, q) - rank(b.name, q) || a.name.length - b.name.length);
        resolve(results.slice(0, limit));
      }
    );
  });
}

function rank(name, q) {
  const n = name.toLowerCase();
  if (n === q) return 0;
  if (n.startsWith(q)) return 1;
  if (n.includes(q)) return 2;
  return 3;
}

// Move the file to the Desktop; never overwrites — renames on collision.
function fetchToDesktop(srcPath) {
  const desktop = path.join(os.homedir(), 'Desktop');
  const name = path.basename(srcPath);
  if (path.dirname(srcPath) === desktop) return srcPath; // already there
  const dest = fs.existsSync(path.join(desktop, name))
    ? uniquePath(desktop, name, ' (fetched by Pudding)')
    : path.join(desktop, name);
  moveAnywhere(srcPath, dest);
  return dest;
}

function revealInFinder(p) {
  execFile('open', ['-R', p]);
}

// Screen position (top-left, in points) of a Desktop icon, via Finder.
// Resolves null if the item has no desktop icon or Automation is declined.
function desktopIconPosition(name) {
  return new Promise((resolve) => {
    const esc = name.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    execFile(
      'osascript',
      ['-e', `tell application "Finder" to get desktop position of item "${esc}"`],
      { timeout: 3000 },
      (err, stdout) => {
        if (err) return resolve(null);
        const m = String(stdout).trim().match(/(-?\d+)\D+(-?\d+)/);
        resolve(m ? { x: +m[1], y: +m[2] } : null);
      }
    );
  });
}

// Retry a few times — Finder needs a beat to place a newly-arrived icon.
async function waitForIconPosition(name, tries = 6, gap = 350) {
  for (let i = 0; i < tries; i++) {
    const pos = await desktopIconPosition(name);
    if (pos) return pos;
    await new Promise((r) => setTimeout(r, gap));
  }
  return null;
}

// If p lives on the Desktop (directly or in a subfolder), the name of the
// top-level item whose icon is visible on the desktop; else null.
function desktopTopLevelItem(p) {
  const desk = path.join(os.homedir(), 'Desktop');
  if (p === desk || !p.startsWith(desk + path.sep)) return null;
  return p.slice(desk.length + 1).split(path.sep)[0];
}

module.exports = {
  search, fetchToDesktop, revealInFinder,
  desktopIconPosition, waitForIconPosition, desktopTopLevelItem,
};
