# Desktop Pudding 🐶

Pudding, as a pixel-art desktop pet for macOS. He lives in a kennel on your
screen, wanders around when he feels like it, eats files you want gone, and
fetches files you've lost.

## Run

```bash
cd desktop-pudding
npm install   # first time only
npm start
```

A 🐶 icon appears in the menu bar; the kennel appears bottom-right and
Pudding starts snoozing in it.

## What he does

**Idle life** — Pudding mostly sleeps in his kennel, but sometimes trots out,
sits or lies down anywhere on the screen, naps there, and eventually heads
home. Click him to pet him (tail wag + hearts). Drag him to
move him. Drag the kennel to reposition it (remembered between launches).

**Kennel = trash bin** — Drag files or folders onto the kennel: they move
into his "bowl" (a staging folder, like the Trash), so nothing is deleted
yet. The badge and the food bowl kibble show how many items are staged.
Right-click the kennel (or Pudding, or use the 🐶 menu-bar icon) for:

- **Feed Pudding — delete N items** — permanently deletes everything in the
  bowl, after one confirmation. Pudding runs over and eats.
- **Take everything back** — restores staged files to where they came from
  (never overwrites; renames with "(from Pudding)" on collision).
- **Open bowl folder** — inspect what's staged in Finder.

**Find & fetch** — "Ask Pudding to fetch…" opens a search box (Spotlight
under the hood). For any result:

- **Fetch to Desktop** — moves the file to your Desktop, then Pudding carries
  the document over and drops it right where it landed, with a bouncing
  "Here you go!" marker pointing at the spot. Never overwrites — renames with
  "(fetched by Pudding)" if needed.
- **Find in Finder** — Pudding dives in and the file is revealed in Finder.

If the file lives in a folder on your **Desktop**, Pudding dives straight
into that real folder icon. (For files elsewhere on the Mac, a pixel folder
pops open mid-screen and he dives into that instead.)

**Commands** (right-click menu / 🐶 menu-bar icon):

- **Sit** — Pudding sits down and stays sitting.
- **Stay** — he holds his spot; after a bit he lies down, and after a while
  longer he falls asleep.
- **Chase the mouse!** — he chases your cursor. If he doesn't catch it within
  a minute he flops down tired, tongue lolling. If he *catches* it, he grabs
  it and parades it around the screen for ten seconds — actually dragging your
  pointer — before letting go.
- **Roam / relax** — cancels sit/stay/chase and returns him to normal life.

Other menu items: **Stay in the kennel when idle** (keep him home instead of
wandering), **Send Pudding to his kennel**, **Pet Pudding**, **Reset kennel
position**, **Quit**.

> Chasing moves your real cursor only while he's got it (≈10s), and needs no
> special permission. Any other command, or just grabbing the mouse back,
> ends it immediately. The cursor-mover is a tiny Swift helper compiled on
> first use; if `swiftc` isn't available he still does the whole chase, just
> without tugging the pointer.

## Notes

- The bowl staging folder lives in
  `~/Library/Application Support/Desktop Pudding/bowl/`.
- Fetch search uses Spotlight (`mdfind`), scoped to your home folder.
- Diving into real Desktop folders and placing the "Here you go!" marker use
  Finder via AppleScript. The **first** fetch shows a macOS prompt — *"Desktop
  Pudding wants to control Finder"* — click **OK**. If you decline, everything
  still works; Pudding just uses the pop-up pixel folder and skips the marker.
- Tests: `npm test` (staging / take-back / feed / collision-rename logic).
